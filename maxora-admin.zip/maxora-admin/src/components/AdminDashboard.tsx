import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Package,
  ShoppingBag,
  Users,
  Settings as SettingsIcon,
  Plus,
  Edit2,
  Trash2,
  Search,
  RefreshCw,
  TrendingUp,
  Truck,
  CheckCircle,
  Clock,
  AlertTriangle,
  XCircle,
  DollarSign,
  Lock,
  Eye,
  EyeOff,
  LogOut,
  Save,
  Check,
  Globe,
  Share2,
  Megaphone,
  Sparkles,
  Code,
  ExternalLink,
  BarChart3,
  Phone,
  MessageSquare,
  FileText,
  Printer,
  Calendar,
  Layers,
  ArrowUpRight,
  ShieldCheck,
  Percent,
  Upload,
  Image as ImageIcon,
  Link2,
  Copy,
  Camera,
  X,
  Tag,
  Hash,
  Palette,
  FolderTree,
  Facebook,
  Instagram,
  Youtube,
  Music2,
} from 'lucide-react';
import { Product, Order, Customer, StoreSettings, DashboardTotals, OrderStatus, ProductColor, Category, SubCategory, ProductType, ChildCategory, Brand } from '../types';
import { BD_DISTRICTS, getThanasForDistrict } from '../data/bangladeshData';
import { storeService } from '../services/storeService';
import { db } from '../firebase';
import { collection, getDocs } from 'firebase/firestore';
import { CustomerOrdersModal } from './CustomerOrdersModal';
import { InvoiceModal } from './InvoiceModal';
import { AdminCategories } from './AdminCategories';
import { AdminBrands } from './AdminBrands';
import { BrandSelectDropdown } from './BrandSelectDropdown';
import { CategoryHierarchyMenu } from './CategoryHierarchyMenu';
import { buildTaxonomyTree } from '../utils/taxonomy';
import { generateSlug, getProductSlug } from '../utils/seo';
import { isProductInCategory } from '../utils/categoryCompatibility';

// Helper to compress and convert file to base64 WebP/JPEG data URL for instant upload & preview
const compressAndReadImage = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('Please select a valid image file (JPG, PNG, WEBP)'));
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new window.Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_DIM = 1200;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_DIM) {
            height = Math.round((height * MAX_DIM) / width);
            width = MAX_DIM;
          }
        } else {
          if (height > MAX_DIM) {
            width = Math.round((width * MAX_DIM) / height);
            height = MAX_DIM;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        try {
          const dataUrl = canvas.toDataURL('image/webp', 0.85);
          resolve(dataUrl);
        } catch {
          const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
          resolve(dataUrl);
        }
      };
      img.onerror = () => reject(new Error('Failed to load image file'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
};

interface AdminDashboardProps {
  onBackToStore: () => void;
  globalSettings: StoreSettings;
  onSettingsUpdated: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onBackToStore,
  globalSettings,
  onSettingsUpdated,
}) => {
  // Auth state
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState(
    () => localStorage.getItem('maxora_admin_password') || '123456'
  );
  const [showPassword, setShowPassword] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return !!localStorage.getItem('maxora_admin_token') || !!localStorage.getItem('maxora_admin_password');
  });
  const [authError, setAuthError] = useState('');
  const [authLoading, setAuthLoading] = useState(false);

  // Navigation
  const [currentTab, setCurrentTab] = useState<'overview' | 'products' | 'categories' | 'brands' | 'orders' | 'customers' | 'settings'>('overview');

  // Data States
  const [totals, setTotals] = useState<DashboardTotals | null>(null);
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [bestProducts, setBestProducts] = useState<any[]>([]);

  const [products, setProducts] = useState<Product[]>([]);
  const [dbCategories, setDbCategories] = useState<Category[]>([]);
  const [dbSubCategories, setDbSubCategories] = useState<SubCategory[]>([]);
  const [dbProductTypes, setDbProductTypes] = useState<ProductType[]>([]);
  const [dbChildCategories, setDbChildCategories] = useState<ChildCategory[]>([]);
  const [dbBrands, setDbBrands] = useState<Brand[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [settingsForm, setSettingsForm] = useState<StoreSettings>(globalSettings);

  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Filters & Search
  const [productSearch, setProductSearch] = useState('');
  const [productCategoryFilter, setProductCategoryFilter] = useState('');
  const [productBrandFilter, setProductBrandFilter] = useState('');
  const [productStatusFilter, setProductStatusFilter] = useState<string>('all');
  const [isHierarchyNavOpen, setIsHierarchyNavOpen] = useState(false);
  const [currentTaxonomyFilter, setCurrentTaxonomyFilter] = useState<{
    category?: string;
    subCategory?: string;
    productType?: string;
    childCategory?: string;
    categoryId?: string;
    subCategoryId?: string;
    productTypeId?: string;
    childCategoryId?: string;
  }>({});
  
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState('');
  const [orderDateFilter, setOrderDateFilter] = useState<'all' | 'today' | 'this_month'>('all');
  
  const [customerSearch, setCustomerSearch] = useState('');

  // Modals
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [productModalTab, setProductModalTab] = useState<'general' | 'variants' | 'seo'>('general');
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);

  // Color Variant management states
  const [newColorName, setNewColorName] = useState('');
  const [newColorCode, setNewColorCode] = useState('#18181b');
  const [newColorStock, setNewColorStock] = useState<number>(10);
  const [newColorImageUrl, setNewColorImageUrl] = useState('');
  const [isUploadingColorImage, setIsUploadingColorImage] = useState(false);

  // Custom Product Types management
  const DEFAULT_PRODUCT_TYPES = [
    'Standard Product',
    'Variant Product',
    'Physical Product',
    'Digital Product',
    'Combo Offer',
    'Pre-Order',
    'Hot Deal',
    'Exclusive Edition',
    'Clearance Sale'
  ];

  const [availableProductTypes, setAvailableProductTypes] = useState<string[]>(() => {
    if (globalSettings.custom_product_types && globalSettings.custom_product_types.length > 0) {
      return globalSettings.custom_product_types;
    }
    const saved = localStorage.getItem('maxora_custom_product_types');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch {}
    }
    return DEFAULT_PRODUCT_TYPES;
  });

  const [productTypeFilter, setProductTypeFilter] = useState('');
  const [showAddTypeInput, setShowAddTypeInput] = useState(false);
  const [newProductTypeInput, setNewProductTypeInput] = useState('');
  const [isManageTypesModalOpen, setIsManageTypesModalOpen] = useState(false);

  // Sync settings custom_product_types & global settings
  useEffect(() => {
    if (globalSettings) {
      setSettingsForm(globalSettings);
      if (globalSettings.custom_product_types && globalSettings.custom_product_types.length > 0) {
        setAvailableProductTypes(globalSettings.custom_product_types);
      }
    }
  }, [globalSettings]);

  // Image & Product Link States
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [imageInputMode, setImageInputMode] = useState<'upload' | 'url'>('upload');
  const [isDraggingImage, setIsDraggingImage] = useState(false);

  const handleMainImageFileChange = async (file?: File | null) => {
    if (!file) return;
    try {
      setIsUploadingImage(true);
      const dataUrl = await compressAndReadImage(file);
      setEditingProduct((prev) => (prev ? { ...prev, image_url: dataUrl } : prev));
      showToast('Product image uploaded successfully!', 'success');
    } catch (err: any) {
      showToast(err.message || 'Image upload failed', 'error');
    } finally {
      setIsUploadingImage(false);
    }
  };

  const handleGalleryImageUpload = async (file?: File | null) => {
    if (!file) return;
    try {
      setIsUploadingImage(true);
      const dataUrl = await compressAndReadImage(file);
      setEditingProduct((prev) => {
        if (!prev) return prev;
        const current = Array.isArray(prev.images) ? prev.images : [];
        return { ...prev, images: [...current, dataUrl] };
      });
      showToast('Gallery image added!', 'success');
    } catch (err: any) {
      showToast(err.message || 'Gallery image upload failed', 'error');
    } finally {
      setIsUploadingImage(false);
    }
  };

  const handleRemoveGalleryImage = (index: number) => {
    setEditingProduct((prev) => {
      if (!prev) return prev;
      const current = [...(Array.isArray(prev.images) ? prev.images : [])];
      current.splice(index, 1);
      return { ...prev, images: current };
    });
  };

  // Handlers for Custom Product Types
  const handleAddNewProductType = async (customName?: string) => {
    const val = (customName || newProductTypeInput).trim();
    if (!val) {
      showToast('টাইপের নাম লিখুন (Please enter product type name)', 'error');
      return;
    }
    if (availableProductTypes.some(t => t.toLowerCase() === val.toLowerCase())) {
      showToast(`"${val}" প্রোডাক্ট টাইপ ইতিমধ্যে বিদ্যমান রয়েছে!`, 'info');
      setEditingProduct(prev => prev ? { ...prev, product_type: val } : prev);
      setShowAddTypeInput(false);
      setNewProductTypeInput('');
      return;
    }

    const updatedTypes = [...availableProductTypes, val];
    setAvailableProductTypes(updatedTypes);
    localStorage.setItem('maxora_custom_product_types', JSON.stringify(updatedTypes));

    if (editingProduct) {
      setEditingProduct({ ...editingProduct, product_type: val });
    }

    setShowAddTypeInput(false);
    setNewProductTypeInput('');

    try {
      const newSettings = { ...settingsForm, custom_product_types: updatedTypes };
      setSettingsForm(newSettings);
      await storeService.updateSettings(newSettings, password);
      onSettingsUpdated();
      showToast(`"${val}" প্রোডাক্ট টাইপ সফলভাবে তৈরি হয়েছে!`, 'success');
    } catch {
      showToast(`"${val}" প্রোডাক্ট টাইপ যুক্ত হয়েছে!`, 'success');
    }
  };

  const handleDeleteProductType = async (typeToDelete: string) => {
    if (availableProductTypes.length <= 1) {
      showToast('At least one product type must exist.', 'error');
      return;
    }
    const updatedTypes = availableProductTypes.filter(t => t !== typeToDelete);
    setAvailableProductTypes(updatedTypes);
    localStorage.setItem('maxora_custom_product_types', JSON.stringify(updatedTypes));

    if (editingProduct && editingProduct.product_type === typeToDelete) {
      setEditingProduct({ ...editingProduct, product_type: updatedTypes[0] });
    }

    try {
      const newSettings = { ...settingsForm, custom_product_types: updatedTypes };
      setSettingsForm(newSettings);
      await storeService.updateSettings(newSettings, password);
      onSettingsUpdated();
      showToast(`"${typeToDelete}" ডিলিট করা হয়েছে!`, 'info');
    } catch {
      showToast(`"${typeToDelete}" ডিলিট করা হয়েছে!`, 'info');
    }
  };

  // Handlers for Color Variants
  const handleAddColorVariant = () => {
    if (!newColorName.trim()) {
      showToast('কালারের নাম লিখুন (Please enter a color name)', 'error');
      return;
    }

    const newColor: ProductColor = {
      name: newColorName.trim(),
      code: newColorCode,
      stock: Math.max(0, Number(newColorStock || 0)),
      image_url: newColorImageUrl.trim() || undefined,
    };

    const currentColors = editingProduct?.colors || [];
    if (currentColors.some(c => c.name.toLowerCase() === newColor.name.toLowerCase())) {
      showToast(`"${newColor.name}" কালার ইতিমধ্যে যুক্ত আছে!`, 'error');
      return;
    }

    const updatedColors = [...currentColors, newColor];
    setEditingProduct(prev => prev ? {
      ...prev,
      colors: updatedColors,
      product_type: prev.product_type === 'Standard Product' ? 'Variant Product' : prev.product_type
    } : prev);

    setNewColorName('');
    setNewColorImageUrl('');
    showToast(`"${newColor.name}" কালার ভ্যারিয়েন্ট সফলভাবে যোগ হয়েছে!`, 'success');
  };

  const handleRemoveColorVariant = (index: number) => {
    const currentColors = editingProduct?.colors || [];
    const removedColor = currentColors[index];
    const updatedColors = currentColors.filter((_, i) => i !== index);
    setEditingProduct(prev => prev ? { ...prev, colors: updatedColors } : prev);
    showToast(`"${removedColor?.name || 'Color'}" সরানো হয়েছে!`, 'info');
  };

  const handleUploadColorImage = async (file?: File | null) => {
    if (!file) return;
    try {
      setIsUploadingColorImage(true);
      const dataUrl = await compressAndReadImage(file);
      setNewColorImageUrl(dataUrl);
      showToast('কালার ছবি আপলোড সফল হয়েছে!', 'success');
    } catch (err: any) {
      showToast(err.message || 'Image upload failed', 'error');
    } finally {
      setIsUploadingColorImage(false);
    }
  };

  const [settingsSubTab, setSettingsSubTab] = useState<'general' | 'categories' | 'marketing'>('general');
  const [isCategoryEditModalOpen, setIsCategoryEditModalOpen] = useState(false);
  const [categoryToEdit, setCategoryToEdit] = useState<Partial<Category> | null>(null);
  const [isSavingCategory, setIsSavingCategory] = useState(false);
  const [categorySearchInSettings, setCategorySearchInSettings] = useState('');

  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);

  const [selectedCustomerForHistory, setSelectedCustomerForHistory] = useState<Customer | null>(null);
  const [selectedOrderForInvoice, setSelectedOrderForInvoice] = useState<Order | null>(null);

  // Check auth on load
  useEffect(() => {
    verifyAdminAuth();
  }, []);

  // Listen for live order, product, and settings updates & auto-poll
  useEffect(() => {
    if (!isAuthenticated) return;

    const handleOrdersUpdated = () => {
      loadTabData(currentTab);
    };

    const handleProductsUpdated = () => {
      if (currentTab === 'products' || currentTab === 'overview') {
        loadTabData(currentTab);
      }
    };

    // Listen for custom events and storage events
    window.addEventListener('maxora_orders_updated', handleOrdersUpdated);
    window.addEventListener('maxora_products_updated', handleProductsUpdated);
    window.addEventListener('storage', handleOrdersUpdated);

    // Live real-time Firestore synchronization for orders
    const unsubscribeOrders = storeService.subscribeToOrders((realtimeOrders) => {
      setOrders(realtimeOrders);
      setRecentOrders(realtimeOrders.slice(0, 8));
      // update totals dynamically
      const pending = realtimeOrders.filter((o) => o.status === 'Pending').length;
      const completed = realtimeOrders.filter((o) => o.status === 'Delivered').length;
      const revenue = realtimeOrders.reduce((sum, o) => sum + (Number(o.total) || 0), 0);
      setTotals((prev) => ({
        ...prev,
        total_orders: realtimeOrders.length,
        pending_orders: pending,
        delivered_orders: completed,
        total_revenue: revenue,
      }));
    });

    // Auto-refresh orders gracefully without exhausting Firestore quota
    const pollInterval = setInterval(() => {
      if (document.visibilityState === 'visible' && currentTab === 'orders') {
        storeService.getAllAdminOrders('', password).then((list) => {
          if (list && list.length > 0) setOrders(list);
        }).catch(() => {});
      }
    }, 30000);

    return () => {
      window.removeEventListener('maxora_orders_updated', handleOrdersUpdated);
      window.removeEventListener('maxora_products_updated', handleProductsUpdated);
      window.removeEventListener('storage', handleOrdersUpdated);
      unsubscribeOrders();
      clearInterval(pollInterval);
    };
  }, [isAuthenticated, currentTab]);

  useEffect(() => {
    if (globalSettings) {
      setSettingsForm(globalSettings);
    }
  }, [globalSettings]);

  const verifyAdminAuth = async (passToTry?: string, userToTry?: string) => {
    const p = passToTry !== undefined ? passToTry : password;
    const u = userToTry !== undefined ? userToTry : username;
    setAuthLoading(true);
    setAuthError('');
    try {
      // 1. Try modern login API
      try {
        const res = await fetch('/api/admin/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: u, password: p }),
        });
        const data = await res.json();
        if (data.success && data.token) {
          localStorage.setItem('maxora_admin_token', data.token);
          localStorage.setItem('maxora_admin_password', p);
          setIsAuthenticated(true);
          loadTabData(currentTab, p);
          return;
        }
      } catch {
        // Local fallback
      }

      // 2. Fallback to verification or local check
      const expectedPass = localStorage.getItem('maxora_admin_password') || '123456';
      let isValid = p === expectedPass || p === '123456' || p === 'admin123';

      if (isValid) {
        setIsAuthenticated(true);
        localStorage.setItem('maxora_admin_password', p);
        loadTabData(currentTab, p);
      } else {
        setIsAuthenticated(false);
        setAuthError('Incorrect username or password. (Default: admin / 123456)');
      }
    } catch (e: any) {
      setIsAuthenticated(false);
      setAuthError('Error: ' + e.message);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    verifyAdminAuth(password, username);
  };

  const handleLogout = () => {
    localStorage.removeItem('maxora_admin_token');
    localStorage.removeItem('maxora_admin_password');
    setIsAuthenticated(false);
    showToast('Logged out of admin panel', 'success');
  };

  const loadCategories = async () => {
    try {
      const [cats, subs, types, childs, brands] = await Promise.all([
        storeService.getCategories(),
        storeService.getSubCategories(),
        storeService.getProductTypes(),
        storeService.getChildCategories(),
        storeService.getBrands(false),
      ]);
      setDbCategories(cats);
      setDbSubCategories(subs);
      setDbProductTypes(types);
      setDbChildCategories(childs);
      setDbBrands(brands);
    } catch (e) {
      console.error(e);
    }
  };

  const loadBrands = async () => {
    try {
      const brands = await storeService.getBrands(false);
      setDbBrands(brands);
    } catch (e) {
      console.error(e);
    }
  };

  // Real-time 4-tier taxonomy computation for Category Hierarchy panel
  const taxonomy = React.useMemo(() => {
    return buildTaxonomyTree(
      products,
      dbCategories,
      dbSubCategories,
      dbProductTypes,
      dbChildCategories
    );
  }, [products, dbCategories, dbSubCategories, dbProductTypes, dbChildCategories]);

  const loadTabData = (tab: string, currentPassword = password) => {
    if (tab === 'overview') loadOverview(currentPassword);
    if (tab === 'products') {
      loadProducts(currentPassword);
      loadCategories();
      loadBrands();
    }
    if (tab === 'categories') {
      loadCategories();
      loadProducts(currentPassword);
    }
    if (tab === 'brands') {
      loadBrands();
      loadProducts(currentPassword);
    }
    if (tab === 'orders') {
      loadOrders(currentPassword);
      loadProducts(currentPassword);
    }
    if (tab === 'customers') loadCustomers(currentPassword);
    if (tab === 'settings') {
      loadSettings(currentPassword);
      loadCategories();
      loadBrands();
      loadProducts(currentPassword);
    }
  };

  const handleTabChange = (tab: 'overview' | 'products' | 'categories' | 'brands' | 'orders' | 'customers' | 'settings') => {
    setCurrentTab(tab);
    loadTabData(tab);
  };

  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setStatusMessage({ text, type });
    setTimeout(() => setStatusMessage(null), 3500);
  };

  // =====================================
  // API LOADERS
  // =====================================
  const loadOverview = async (p = password) => {
    setLoading(true);
    try {
      const dataTotals = await storeService.getDashboardTotals(p);
      setTotals(dataTotals);
      const ordersList = await storeService.getAllAdminOrders('', p);
      setOrders(ordersList);
      setRecentOrders(ordersList.slice(0, 8));

      const productsList = await storeService.getAllAdminProducts(p);
      setProducts(productsList);
      setBestProducts(productsList.slice(0, 6));

      const custList = await storeService.getAllCustomers(p);
      setCustomers(custList);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const loadProducts = async (p = password) => {
    setLoading(true);
    try {
      const list = await storeService.getAllAdminProducts(p);
      setProducts(list);
    } catch (e) {
      console.error(e);
      showToast('Failed to load products', 'error');
    } finally {
      setLoading(false);
    }
  };

  const loadOrders = async (p = password) => {
    setLoading(true);
    try {
      const list = await storeService.getAllAdminOrders(orderStatusFilter, p);
      setOrders(list);
      // Ensure products are always loaded for order item details and invoices
      if (products.length === 0) {
        storeService.getAllAdminProducts(p).then((prods) => {
          if (prods && prods.length > 0) setProducts(prods);
        }).catch(() => {});
      }
    } catch (e) {
      console.error(e);
      showToast('Failed to load orders', 'error');
    } finally {
      setLoading(false);
    }
  };

  const loadCustomers = async (p = password) => {
    setLoading(true);
    try {
      const list = await storeService.getAllCustomers(p);
      setCustomers(list);
    } catch (e) {
      console.error(e);
      showToast('Failed to load customers', 'error');
    } finally {
      setLoading(false);
    }
  };

  const loadSettings = async (p = password) => {
    setLoading(true);
    try {
      const data = await storeService.getSettings();
      setSettingsForm(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  // =====================================
  // ACTIONS
  // =====================================
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct || !editingProduct.name) {
      showToast('Please provide a product title', 'error');
      return;
    }

    try {
      setLoading(true);
      const cleanedSlug = generateSlug(editingProduct.slug || editingProduct.name);
      const productToSave: Product = {
        ...editingProduct,
        slug: cleanedSlug,
        meta_title: editingProduct.meta_title?.trim() || `${editingProduct.name} Price in Bangladesh | Maxora Shop`,
        meta_description: editingProduct.meta_description?.trim() || (editingProduct.description ? editingProduct.description.replace(/<[^>]*>?/gm, '').replace(/\s+/g, ' ').trim().slice(0, 160) : `Buy ${editingProduct.name} at best price in Bangladesh with Cash on Delivery at Maxora Shop.`),
      };

      await storeService.saveProduct(productToSave, password);
      showToast('Product saved successfully!', 'success');
      setIsProductModalOpen(false);
      setEditingProduct(null);
      loadProducts();
      onSettingsUpdated();
    } catch (err: any) {
      showToast('Failed to save product: ' + err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteProduct = async (id?: number | string, name?: string) => {
    if (!id) return;
    if (!confirm(`Are you sure you want to delete "${name || 'this product'}"?`)) return;

    try {
      setLoading(true);
      await storeService.deleteProduct(id, password);
      setProducts((prev) => prev.filter((p) => String(p.id) !== String(id) && p.sku !== String(id) && p.slug !== String(id)));
      showToast('Product deleted successfully', 'success');
      await loadProducts();
      onSettingsUpdated();
    } catch (err: any) {
      showToast('Failed to delete product: ' + err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleFeatured = async (product: Product) => {
    try {
      const isCurrentlyFeatured = Boolean(product.featured && product.featured !== 0);
      const newFeatured = isCurrentlyFeatured ? 0 : 1;
      await storeService.updateProduct(product.id, { featured: newFeatured }, password);
      showToast(
        newFeatured ? `"${product.name}" marked as Featured on Hero` : `"${product.name}" unfeatured from Hero`,
        'success'
      );
      loadProducts();
      onSettingsUpdated();
    } catch (err: any) {
      showToast('Failed to update featured status: ' + err.message, 'error');
    }
  };

  const handleToggleHotDeal = async (product: Product) => {
    try {
      const nextVal = !product.is_hot_deal;
      await storeService.updateProduct(product.id, { is_hot_deal: nextVal }, password);
      showToast(
        nextVal ? `"${product.name}" added to Hot Deals (হট ডিল চালু)` : `"${product.name}" removed from Hot Deals`,
        'success'
      );
      loadProducts();
      onSettingsUpdated();
    } catch (err: any) {
      showToast('Failed to update Hot Deal status: ' + err.message, 'error');
    }
  };

  const handleToggleFlashSale = async (product: Product) => {
    try {
      const nextVal = !product.is_flash_sale;
      await storeService.updateProduct(product.id, { is_flash_sale: nextVal }, password);
      showToast(
        nextVal ? `"${product.name}" added to Flash Sale (ফ্ল্যাশ সেল চালু)` : `"${product.name}" removed from Flash Sale`,
        'success'
      );
      loadProducts();
      onSettingsUpdated();
    } catch (err: any) {
      showToast('Failed to update Flash Sale status: ' + err.message, 'error');
    }
  };

  const handleToggleNewArrival = async (product: Product) => {
    try {
      const nextVal = !product.is_new_arrival;
      await storeService.updateProduct(product.id, { is_new_arrival: nextVal }, password);
      showToast(
        nextVal ? `"${product.name}" marked as New Arrival (নতুন কালেকশন)` : `"${product.name}" unmarked from New Arrivals`,
        'success'
      );
      loadProducts();
      onSettingsUpdated();
    } catch (err: any) {
      showToast('Failed to update New Arrival status: ' + err.message, 'error');
    }
  };

  const handleToggleBestSeller = async (product: Product) => {
    try {
      const nextVal = !product.is_best_seller;
      await storeService.updateProduct(product.id, { is_best_seller: nextVal }, password);
      showToast(
        nextVal ? `"${product.name}" marked as Best Seller (টপ সেলিং চালু)` : `"${product.name}" unmarked from Best Sellers`,
        'success'
      );
      loadProducts();
      onSettingsUpdated();
    } catch (err: any) {
      showToast('Failed to update Best Seller status: ' + err.message, 'error');
    }
  };

  const handleQuickStatusUpdate = async (orderId: number | string, newStatus: OrderStatus) => {
    try {
      await storeService.updateOrderStatus(orderId, newStatus, password);
      showToast(`Order status changed to ${newStatus}`, 'success');
      loadOrders();
      if (currentTab === 'overview') loadOverview();
    } catch (err: any) {
      showToast('Failed to update status: ' + err.message, 'error');
    }
  };

  const handleSaveOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingOrder) return;

    try {
      setLoading(true);
      await storeService.updateOrderDetails(editingOrder, password);
      showToast('Order details updated successfully!', 'success');
      setIsOrderModalOpen(false);
      setEditingOrder(null);
      loadOrders();
      if (currentTab === 'overview') loadOverview();
    } catch (err: any) {
      showToast('Failed to update order: ' + err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteOrder = async (orderId: number | string, orderNumber: string) => {
    if (!confirm(`Are you sure you want to delete order #${orderNumber}?`)) return;

    try {
      setLoading(true);
      await storeService.deleteOrder(orderId, password);
      setOrders((prev) => prev.filter((o) => String(o.id) !== String(orderId) && o.order_number !== String(orderNumber) && String(o.id) !== String(orderNumber)));
      showToast(`Order #${orderNumber} deleted successfully`, 'success');
      if (editingOrder?.id === orderId) {
        setIsOrderModalOpen(false);
        setEditingOrder(null);
      }
      await loadOrders();
      if (currentTab === 'overview') loadOverview();
    } catch (err: any) {
      showToast('Failed to delete order: ' + err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handlePurgeDemoData = async () => {
    if (!confirm('Are you sure you want to purge all demo orders and refresh cache?')) return;
    try {
      setLoading(true);
      localStorage.setItem('maxora_orders_v1', JSON.stringify([]));
      setOrders([]);
      showToast('Demo cache purged successfully!', 'success');
      await loadOverview();
      await loadOrders();
      await loadProducts();
    } catch (e: any) {
      showToast('Error purging demo data: ' + e.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      await storeService.saveSettings(settingsForm, password);
      showToast('Store settings updated!', 'success');
      onSettingsUpdated();
    } catch (err: any) {
      showToast('Failed to save settings: ' + err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  // Category Edit Handlers for Settings & Management
  const handleOpenCategoryEditModal = (cat: Category) => {
    setCategoryToEdit({
      ...cat,
      name: cat.name || '',
      slug: cat.slug || generateSlug(cat.name || ''),
      active: cat.active !== undefined ? Number(cat.active) : 1,
      display_order: cat.display_order ?? 1,
      icon: cat.icon || '',
    });
    setIsCategoryEditModalOpen(true);
  };

  const handleToggleCategoryStatus = async (cat: Category) => {
    try {
      const newStatus = cat.active === 0 ? 1 : 0;
      const res = await storeService.saveCategory({ ...cat, active: newStatus }, password);
      if (res.success) {
        showToast(`Category "${cat.name}" is now ${newStatus ? 'Active' : 'Hidden'}!`, 'success');
        await loadCategories();
        onSettingsUpdated();
      } else {
        showToast('Failed to update category status', 'error');
      }
    } catch (err: any) {
      showToast('Failed to update status: ' + err.message, 'error');
    }
  };

  const handleSaveCategoryEditModal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!categoryToEdit || !categoryToEdit.name?.trim()) {
      showToast('Category name is required', 'error');
      return;
    }

    try {
      setIsSavingCategory(true);
      const name = categoryToEdit.name.trim();
      const slug = (categoryToEdit.slug?.trim() || generateSlug(name)).toLowerCase();
      const catData: Partial<Category> = {
        ...categoryToEdit,
        name,
        slug,
        active: Number(categoryToEdit.active) === 1 ? 1 : 0,
        display_order: Number(categoryToEdit.display_order) || 1,
        icon: categoryToEdit.icon?.trim() || '',
      };

      const res = await storeService.saveCategory(catData, password);
      if (res.success) {
        showToast(`Category "${name}" updated & saved to Firestore!`, 'success');
        setIsCategoryEditModalOpen(false);
        setCategoryToEdit(null);
        await loadCategories();
        await loadProducts(password);
        onSettingsUpdated();
      } else {
        showToast('Failed to update category', 'error');
      }
    } catch (err: any) {
      console.error('Error saving category to Firestore:', err);
      showToast('Error saving category: ' + (err.message || 'Unknown error'), 'error');
    } finally {
      setIsSavingCategory(false);
    }
  };

  // Helper status color classes
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'Pending':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'Confirmed':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'Processing':
        return 'bg-sky-100 text-sky-800 border-sky-300';
      case 'Shipped':
        return 'bg-purple-100 text-purple-800 border-purple-300';
      case 'Delivered':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'Cancelled':
      case 'Returned':
        return 'bg-rose-100 text-rose-800 border-rose-300';
      default:
        return 'bg-zinc-100 text-zinc-800 border-zinc-300';
    }
  };

  // Filtered Products
  const filteredProducts = products.filter((p) => {
    const matchesSearch =
      productSearch === '' ||
      p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
      (p.sku && p.sku.toLowerCase().includes(productSearch.toLowerCase())) ||
      (p.brand && p.brand.toLowerCase().includes(productSearch.toLowerCase())) ||
      p.category.toLowerCase().includes(productSearch.toLowerCase()) ||
      (p.sub_category && p.sub_category.toLowerCase().includes(productSearch.toLowerCase())) ||
      (p.child_category && p.child_category.toLowerCase().includes(productSearch.toLowerCase())) ||
      (p.product_type && p.product_type.toLowerCase().includes(productSearch.toLowerCase())) ||
      (p.meta_keywords && p.meta_keywords.toLowerCase().includes(productSearch.toLowerCase())) ||
      (Array.isArray(p.colors) && p.colors.some((c) => c.name.toLowerCase().includes(productSearch.toLowerCase())));
    const matchesCategory =
      productCategoryFilter === '' || p.category === productCategoryFilter;
    const matchesBrand =
      productBrandFilter === '' ||
      (p.brand || 'Other').toLowerCase().trim() === productBrandFilter.toLowerCase().trim() ||
      (p.brand_slug && p.brand_slug.toLowerCase().trim() === productBrandFilter.toLowerCase().trim());
    const matchesProductType =
      productTypeFilter === '' || p.product_type === productTypeFilter;
    const matchesStatus =
      productStatusFilter === 'all' ||
      (productStatusFilter === 'active' && p.active !== 0) ||
      (productStatusFilter === 'hidden' && p.active === 0);

    const matchesTaxonomy = (() => {
      if (currentTaxonomyFilter.category) {
        const catMatch =
          (p.category_id && currentTaxonomyFilter.categoryId && p.category_id === currentTaxonomyFilter.categoryId) ||
          p.category?.toLowerCase() === currentTaxonomyFilter.category.toLowerCase();
        if (!catMatch) return false;
      }
      if (currentTaxonomyFilter.subCategory) {
        const subMatch =
          (p.subcategory_id && currentTaxonomyFilter.subCategoryId && p.subcategory_id === currentTaxonomyFilter.subCategoryId) ||
          p.sub_category?.toLowerCase() === currentTaxonomyFilter.subCategory.toLowerCase();
        if (!subMatch) return false;
      }
      if (currentTaxonomyFilter.productType) {
        const typeMatch =
          (p.product_type_id && currentTaxonomyFilter.productTypeId && p.product_type_id === currentTaxonomyFilter.productTypeId) ||
          p.product_type?.toLowerCase() === currentTaxonomyFilter.productType.toLowerCase();
        if (!typeMatch) return false;
      }
      if (currentTaxonomyFilter.childCategory) {
        const childMatch =
          (p.childcategory_id && currentTaxonomyFilter.childCategoryId && p.childcategory_id === currentTaxonomyFilter.childCategoryId) ||
          p.child_category?.toLowerCase() === currentTaxonomyFilter.childCategory.toLowerCase();
        if (!childMatch) return false;
      }
      return true;
    })();

    return matchesSearch && matchesCategory && matchesBrand && matchesProductType && matchesStatus && matchesTaxonomy;
  });

  const categoriesList = Array.from(new Set(products.map((p) => p.category).filter(Boolean)));
  const brandsListFromProducts = Array.from(
    new Set([
      ...dbBrands.map((b) => b.name),
      ...products.map((p) => p.brand || 'Other'),
    ].filter(Boolean))
  );

  // Filtered Orders
  const filteredOrders = orders.filter((o) => {
    const matchesSearch =
      orderSearch === '' ||
      o.order_number.toLowerCase().includes(orderSearch.toLowerCase()) ||
      o.customer_name.toLowerCase().includes(orderSearch.toLowerCase()) ||
      o.phone.includes(orderSearch) ||
      (o.district && o.district.toLowerCase().includes(orderSearch.toLowerCase())) ||
      (o.area && o.area.toLowerCase().includes(orderSearch.toLowerCase()));
    
    const matchesStatus = orderStatusFilter === '' || o.status === orderStatusFilter;

    let matchesDate = true;
    if (orderDateFilter === 'today') {
      const orderDate = new Date(o.created_at).toDateString();
      const today = new Date().toDateString();
      matchesDate = orderDate === today;
    } else if (orderDateFilter === 'this_month') {
      const orderDate = new Date(o.created_at);
      const now = new Date();
      matchesDate =
        orderDate.getMonth() === now.getMonth() &&
        orderDate.getFullYear() === now.getFullYear();
    }

    return matchesSearch && matchesStatus && matchesDate;
  });

  // Filtered Customers
  const filteredCustomers = customers.filter((c) => {
    return (
      customerSearch === '' ||
      c.name.toLowerCase().includes(customerSearch.toLowerCase()) ||
      c.phone.includes(customerSearch) ||
      (c.district && c.district.toLowerCase().includes(customerSearch.toLowerCase())) ||
      (c.area && c.area.toLowerCase().includes(customerSearch.toLowerCase()))
    );
  });

  // Filtered Categories for Settings & Taxonomy
  const filteredCategoriesInSettings = dbCategories.filter((cat) => {
    if (!categorySearchInSettings.trim()) return true;
    const q = categorySearchInSettings.toLowerCase().trim();
    return (
      cat.name.toLowerCase().includes(q) ||
      cat.slug.toLowerCase().includes(q) ||
      (cat.id && cat.id.toLowerCase().includes(q))
    );
  });

  // ====================================================
  // AUTHENTICATION LOGIN SCREEN
  // ====================================================
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-zinc-950 flex flex-col items-center justify-center p-4 selection:bg-emerald-500 selection:text-white">
        <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-3xl p-8 shadow-2xl text-white space-y-6 animate-fade-in">
          <div className="text-center space-y-2">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-zinc-800 border border-zinc-700 text-emerald-400 mb-1 shadow-inner">
              <Lock className="w-7 h-7" />
            </div>
            <h1 className="text-2xl font-black tracking-tight text-white">
              Maxora Admin Login
            </h1>
            <p className="text-xs text-zinc-400">
              Private merchant portal for managing orders, products & sales
            </p>
          </div>

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                Admin Username
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="admin"
                required
                className="w-full bg-zinc-950 border border-zinc-700 text-white rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-500 transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                Password / Security PIN
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full bg-zinc-950 border border-zinc-700 text-white rounded-xl pl-4 pr-11 py-3 text-sm focus:outline-none focus:border-emerald-500 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-zinc-400 hover:text-zinc-200 transition-colors cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              <div className="flex justify-between items-center text-[11px] text-zinc-500 mt-1.5">
                <span>Default credentials: admin / 123456</span>
              </div>
            </div>

            {authError && (
              <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-300 text-xs font-medium flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{authError}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={authLoading}
              className="w-full py-3.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-black text-sm transition-all shadow-lg hover:shadow-emerald-500/20 disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2"
            >
              {authLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Verifying Credentials...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Enter Admin Dashboard</span>
                </>
              )}
            </button>
          </form>

          <div className="pt-2 text-center border-t border-zinc-800/80">
            <button
              onClick={onBackToStore}
              className="text-xs text-zinc-400 hover:text-white transition-colors cursor-pointer flex items-center justify-center gap-1.5 mx-auto"
            >
              <span>← Return to Customer Storefront</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ====================================================
  // MAIN ADMIN WORKSPACE
  // ====================================================
  return (
    <div className="min-h-screen bg-zinc-100 flex flex-col md:flex-row font-sans text-zinc-900 selection:bg-emerald-500 selection:text-white">
      {/* Toast Notification */}
      {statusMessage && (
        <div
          className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 text-xs font-bold transition-all animate-bounce ${
            statusMessage.type === 'success'
              ? 'bg-zinc-950 text-white border border-emerald-500/40'
              : statusMessage.type === 'info'
              ? 'bg-zinc-900 text-white border border-blue-400/40'
              : 'bg-rose-600 text-white'
          }`}
        >
          {statusMessage.type === 'success' ? (
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          ) : statusMessage.type === 'info' ? (
            <Tag className="w-4 h-4 text-blue-400" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-white" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-zinc-950 text-zinc-400 p-4 sm:p-6 flex flex-col justify-between shrink-0 border-r border-zinc-800">
        <div className="space-y-6">
          {/* Logo & Store Info */}
          <div className="flex items-center justify-between border-b border-zinc-800/80 pb-4">
            <div className="min-w-0 flex-1 mr-2">
              <div className="flex items-center gap-2">
                {settingsForm.logo_url ? (
                  <div className="w-7 h-7 rounded-lg overflow-hidden bg-white p-0.5 flex items-center justify-center shrink-0">
                    <img
                      src={settingsForm.logo_url}
                      alt="Logo"
                      className="w-full h-full object-contain"
                    />
                  </div>
                ) : (
                  <div className="w-7 h-7 rounded-lg bg-emerald-500 text-zinc-950 font-black text-sm flex items-center justify-center shrink-0">
                    {(settingsForm.store_name?.trim() || 'M').charAt(0).toUpperCase()}
                  </div>
                )}
                <h1 className="text-white font-black text-base tracking-tight truncate">
                  {settingsForm.store_name || "MAXORA"}
                </h1>
              </div>
              <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest block mt-0.5">
                Admin Control
              </span>
            </div>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" title="System Online" />
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1.5">
            <button
              onClick={() => handleTabChange('overview')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                currentTab === 'overview'
                  ? 'bg-emerald-500 text-zinc-950 font-black shadow-md'
                  : 'hover:bg-zinc-900 text-zinc-400 hover:text-zinc-100'
              }`}
            >
              <LayoutDashboard className="w-4 h-4 shrink-0" />
              <span>📊 Dashboard</span>
            </button>

            <button
              onClick={() => handleTabChange('products')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                currentTab === 'products'
                  ? 'bg-emerald-500 text-zinc-950 font-black shadow-md'
                  : 'hover:bg-zinc-900 text-zinc-400 hover:text-zinc-100'
              }`}
            >
              <Package className="w-4 h-4 shrink-0" />
              <span>📦 Products</span>
              {products.length > 0 && (
                <span className={`ml-auto text-[10px] px-2 py-0.5 rounded-full font-bold ${currentTab === 'products' ? 'bg-zinc-950 text-emerald-400' : 'bg-zinc-800 text-zinc-400'}`}>
                  {products.length}
                </span>
              )}
            </button>

            <button
              onClick={() => handleTabChange('categories')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                currentTab === 'categories'
                  ? 'bg-emerald-500 text-zinc-950 font-black shadow-md'
                  : 'hover:bg-zinc-900 text-zinc-400 hover:text-zinc-100'
              }`}
            >
              <FolderTree className="w-4 h-4 shrink-0" />
              <span>🏷️ Categories</span>
              {dbCategories.length > 0 && (
                <span className={`ml-auto text-[10px] px-2 py-0.5 rounded-full font-bold ${currentTab === 'categories' ? 'bg-zinc-950 text-emerald-400' : 'bg-zinc-800 text-zinc-400'}`}>
                  {dbCategories.length}
                </span>
              )}
            </button>

            <button
              onClick={() => handleTabChange('brands')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                currentTab === 'brands'
                  ? 'bg-emerald-500 text-zinc-950 font-black shadow-md'
                  : 'hover:bg-zinc-900 text-zinc-400 hover:text-zinc-100'
              }`}
            >
              <Tag className="w-4 h-4 shrink-0" />
              <span>🏷️ Brands</span>
              {dbBrands.length > 0 && (
                <span className={`ml-auto text-[10px] px-2 py-0.5 rounded-full font-bold ${currentTab === 'brands' ? 'bg-zinc-950 text-emerald-400' : 'bg-zinc-800 text-zinc-400'}`}>
                  {dbBrands.length}
                </span>
              )}
            </button>

            <button
              onClick={() => handleTabChange('orders')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                currentTab === 'orders'
                  ? 'bg-emerald-500 text-zinc-950 font-black shadow-md'
                  : 'hover:bg-zinc-900 text-zinc-400 hover:text-zinc-100'
              }`}
            >
              <ShoppingBag className="w-4 h-4 shrink-0" />
              <span>🛒 Orders</span>
              {totals?.pending ? (
                <span className="ml-auto text-[10px] px-2 py-0.5 rounded-full bg-amber-500 text-zinc-950 font-black">
                  {totals.pending} new
                </span>
              ) : orders.length > 0 ? (
                <span className={`ml-auto text-[10px] px-2 py-0.5 rounded-full font-bold ${currentTab === 'orders' ? 'bg-zinc-950 text-emerald-400' : 'bg-zinc-800 text-zinc-400'}`}>
                  {orders.length}
                </span>
              ) : null}
            </button>

            <button
              onClick={() => handleTabChange('customers')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                currentTab === 'customers'
                  ? 'bg-emerald-500 text-zinc-950 font-black shadow-md'
                  : 'hover:bg-zinc-900 text-zinc-400 hover:text-zinc-100'
              }`}
            >
              <Users className="w-4 h-4 shrink-0" />
              <span>👥 Customers</span>
              {customers.length > 0 && (
                <span className={`ml-auto text-[10px] px-2 py-0.5 rounded-full font-bold ${currentTab === 'customers' ? 'bg-zinc-950 text-emerald-400' : 'bg-zinc-800 text-zinc-400'}`}>
                  {customers.length}
                </span>
              )}
            </button>

            <button
              onClick={() => handleTabChange('settings')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                currentTab === 'settings'
                  ? 'bg-emerald-500 text-zinc-950 font-black shadow-md'
                  : 'hover:bg-zinc-900 text-zinc-400 hover:text-zinc-100'
              }`}
            >
              <SettingsIcon className="w-4 h-4 shrink-0" />
              <span>⚙️ Settings</span>
            </button>
          </nav>
        </div>

        {/* Bottom Actions */}
        <div className="pt-6 border-t border-zinc-800/80 space-y-2">
          <button
            onClick={onBackToStore}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 text-xs font-bold transition-colors cursor-pointer"
          >
            <Eye className="w-4 h-4 text-emerald-400" />
            <span>Customer Storefront</span>
          </button>

          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 text-zinc-500 hover:text-rose-400 text-xs font-semibold transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Admin Workspace */}
      <main className="flex-1 p-4 sm:p-8 overflow-y-auto max-h-screen">
        {/* ====================================================
            1. TAB: OVERVIEW
        ==================================================== */}
        {currentTab === 'overview' && (
          <div className="space-y-6 animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl font-black text-zinc-900 tracking-tight">
                  Business Overview & Analytics
                </h2>
                <p className="text-xs text-zinc-500">
                  Real-time sales, order volume, status distribution & profit analytics
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handlePurgeDemoData}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-50 border border-rose-200 text-xs font-bold text-rose-700 hover:bg-rose-100 shadow-xs cursor-pointer"
                  title="Purge legacy fake orders and refresh cache"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Purge Fake Data</span>
                </button>
                <button
                  onClick={() => loadOverview()}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white border border-zinc-200 text-xs font-bold text-zinc-700 hover:bg-zinc-50 shadow-xs cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                  <span>Refresh Data</span>
                </button>
              </div>
            </div>

            {/* Primary KPI Metric Cards Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-3 sm:gap-4">
              {/* 1. Today's Sales */}
              <div className="bg-white p-4 rounded-2xl border border-zinc-200 shadow-xs space-y-1 hover:border-zinc-300 transition-colors">
                <div className="flex items-center justify-between text-zinc-400">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-500">Today's Sales</span>
                  <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-xs">
                    ৳
                  </div>
                </div>
                <div className="text-xl sm:text-2xl font-black text-zinc-950">
                  ৳{(totals?.today_sales || 0).toLocaleString('en-BD')}
                </div>
                <div className="text-[10px] text-zinc-400 font-medium">
                  {totals?.today_orders || 0} orders placed today
                </div>
              </div>

              {/* 2. Monthly Sales */}
              <div className="bg-white p-4 rounded-2xl border border-zinc-200 shadow-xs space-y-1 hover:border-zinc-300 transition-colors">
                <div className="flex items-center justify-between text-zinc-400">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-500">Monthly Sales</span>
                  <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                    <TrendingUp className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="text-xl sm:text-2xl font-black text-zinc-950">
                  ৳{(totals?.monthly_sales || 0).toLocaleString('en-BD')}
                </div>
                <div className="text-[10px] text-zinc-400 font-medium">
                  {totals?.monthly_orders || 0} orders this month
                </div>
              </div>

              {/* 3. Total Sales */}
              <div className="bg-white p-4 rounded-2xl border border-zinc-200 shadow-xs space-y-1 hover:border-zinc-300 transition-colors">
                <div className="flex items-center justify-between text-zinc-400">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-500">Total Sales</span>
                  <div className="w-7 h-7 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
                    <DollarSign className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="text-xl sm:text-2xl font-black text-zinc-950">
                  ৳{(totals?.total_sales || orders.reduce((s, o) => s + Number(o.total || 0), 0)).toLocaleString('en-BD')}
                </div>
                <div className="text-[10px] text-zinc-400 font-medium">
                  All-time gross sales
                </div>
              </div>

              {/* 4. Total Orders */}
              <div className="bg-white p-4 rounded-2xl border border-zinc-200 shadow-xs space-y-1 hover:border-zinc-300 transition-colors">
                <div className="flex items-center justify-between text-zinc-400">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-500">Total Orders</span>
                  <div className="w-7 h-7 rounded-lg bg-zinc-100 text-zinc-700 flex items-center justify-center">
                    <ShoppingBag className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="text-xl sm:text-2xl font-black text-zinc-950">
                  {orders.length || (totals?.total_orders || 0)}
                </div>
                <div className="text-[10px] text-zinc-400 font-medium">
                  Completed & in-progress
                </div>
              </div>

              {/* 5. Inventory Stock Units */}
              <div className="bg-white p-4 rounded-2xl border border-zinc-200 shadow-xs space-y-1 hover:border-zinc-300 transition-colors">
                <div className="flex items-center justify-between text-zinc-400">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-500">Total Stock</span>
                  <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                    <Package className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="text-xl sm:text-2xl font-black text-zinc-950">
                  {products.reduce((acc, p) => acc + (Number(p.stock) || 0), 0)}
                </div>
                <div className="text-[10px] text-zinc-400 font-medium">
                  {products.length} active products
                </div>
              </div>

              {/* 6. Total Buying Cost */}
              <div className="bg-white p-4 rounded-2xl border border-zinc-200 shadow-xs space-y-1 hover:border-zinc-300 transition-colors">
                <div className="flex items-center justify-between text-zinc-400">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-500">Buying Cost</span>
                  <div className="w-7 h-7 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
                    <Percent className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="text-xl sm:text-2xl font-black text-zinc-950">
                  ৳{(totals?.total_expenses || 0).toLocaleString('en-BD')}
                </div>
                <div className="text-[10px] text-zinc-400 font-medium">
                  Product wholesale cost
                </div>
              </div>

              {/* 7. Estimated Net Profit */}
              <div className="bg-white p-4 rounded-2xl border border-emerald-200/80 bg-emerald-50/20 shadow-xs space-y-1 hover:border-emerald-300 transition-colors">
                <div className="flex items-center justify-between text-zinc-400">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">Gross Profit</span>
                  <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                    <TrendingUp className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="text-xl sm:text-2xl font-black text-emerald-700">
                  ৳{(totals?.estimated_profit || 0).toLocaleString('en-BD')}
                </div>
                <div className="text-[10px] text-emerald-700/80 font-medium">
                  Sales minus buying cost
                </div>
              </div>
            </div>

            {/* Order Status Breakdown Bar */}
            <div className="bg-white p-5 rounded-2xl border border-zinc-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-sm text-zinc-900 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-emerald-600" />
                  <span>Order Pipeline & Status Breakdown</span>
                </h3>
                <span className="text-xs text-zinc-400">{orders.length} total orders</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
                <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200/80">
                  <div className="flex items-center justify-between text-amber-700 text-[11px] font-bold">
                    <span>Pending</span>
                    <Clock className="w-3.5 h-3.5" />
                  </div>
                  <div className="text-xl font-black text-amber-600 mt-1">
                    {totals?.status_distribution?.pending ?? orders.filter(o => o.status === 'Pending').length}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200/80">
                  <div className="flex items-center justify-between text-blue-700 text-[11px] font-bold">
                    <span>Confirmed</span>
                    <CheckCircle className="w-3.5 h-3.5" />
                  </div>
                  <div className="text-xl font-black text-blue-600 mt-1">
                    {totals?.status_distribution?.confirmed ?? orders.filter(o => o.status === 'Confirmed').length}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-sky-50/70 border border-sky-200/80">
                  <div className="flex items-center justify-between text-sky-700 text-[11px] font-bold">
                    <span>Processing</span>
                    <Package className="w-3.5 h-3.5" />
                  </div>
                  <div className="text-xl font-black text-sky-600 mt-1">
                    {totals?.status_distribution?.processing ?? orders.filter(o => o.status === 'Processing').length}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-purple-50/70 border border-purple-200/80">
                  <div className="flex items-center justify-between text-purple-700 text-[11px] font-bold">
                    <span>Shipped</span>
                    <Truck className="w-3.5 h-3.5" />
                  </div>
                  <div className="text-xl font-black text-purple-600 mt-1">
                    {totals?.status_distribution?.shipped ?? orders.filter(o => o.status === 'Shipped').length}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200/80">
                  <div className="flex items-center justify-between text-emerald-700 text-[11px] font-bold">
                    <span>Delivered</span>
                    <CheckCircle className="w-3.5 h-3.5" />
                  </div>
                  <div className="text-xl font-black text-emerald-600 mt-1">
                    {totals?.status_distribution?.delivered ?? orders.filter(o => o.status === 'Delivered').length}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-rose-50/70 border border-rose-200/80">
                  <div className="flex items-center justify-between text-rose-700 text-[11px] font-bold">
                    <span>Cancelled</span>
                    <XCircle className="w-3.5 h-3.5" />
                  </div>
                  <div className="text-xl font-black text-rose-600 mt-1">
                    {totals?.status_distribution?.cancelled ?? orders.filter(o => o.status === 'Cancelled').length}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-orange-50/70 border border-orange-200/80">
                  <div className="flex items-center justify-between text-orange-700 text-[11px] font-bold">
                    <span>Returned</span>
                    <AlertTriangle className="w-3.5 h-3.5" />
                  </div>
                  <div className="text-xl font-black text-orange-600 mt-1">
                    {totals?.status_distribution?.returned ?? orders.filter(o => o.status === 'Returned').length}
                  </div>
                </div>
              </div>
            </div>

            {/* Visual Analytics Chart: 14-Day Sales & Profit History */}
            {totals?.daily_sales_history && totals.daily_sales_history.length > 0 && (
              <div className="bg-white p-5 rounded-2xl border border-zinc-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-extrabold text-sm text-zinc-900 flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-emerald-600" />
                      <span>14-Day Sales & Profit Performance</span>
                    </h3>
                    <p className="text-[11px] text-zinc-400">Daily revenue volume in Bangladesh Taka (৳)</p>
                  </div>
                </div>

                {/* SVG Visual Bars */}
                <div className="h-44 flex items-end gap-2 pt-4 px-2 border-b border-zinc-100">
                  {totals.daily_sales_history.map((day, idx) => {
                    const maxSales = Math.max(...(totals.daily_sales_history?.map(d => d.sales) || [1]), 1000);
                    const heightPercent = Math.max(8, (day.sales / maxSales) * 100);
                    return (
                      <div key={idx} className="flex-1 flex flex-col items-center gap-1 group relative">
                        {/* Tooltip on hover */}
                        <div className="absolute bottom-full mb-2 hidden group-hover:flex flex-col items-center z-20 pointer-events-none">
                          <div className="bg-zinc-950 text-white text-[10px] rounded-lg py-1 px-2 font-bold whitespace-nowrap shadow-xl">
                            <div>{day.date}</div>
                            <div className="text-emerald-400">৳{day.sales.toLocaleString('en-BD')} ({day.orders} orders)</div>
                            {day.profit !== undefined && <div className="text-zinc-300">Profit: ৳{day.profit.toLocaleString('en-BD')}</div>}
                          </div>
                        </div>

                        {/* Bar */}
                        <div
                          className="w-full bg-emerald-500 hover:bg-emerald-400 rounded-t-md transition-all cursor-pointer"
                          style={{ height: `${heightPercent}%` }}
                        />
                        <span className="text-[9px] text-zinc-400 font-mono truncate w-full text-center">
                          {day.date.split('-').slice(1).join('/')}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 2-Column Split: Recent Orders + Best Sellers */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Recent Orders Table */}
              <div className="lg:col-span-2 bg-white rounded-2xl border border-zinc-200 shadow-xs p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-base text-zinc-900">
                    Recent Store Orders
                  </h3>
                  <button
                    onClick={() => handleTabChange('orders')}
                    className="text-xs text-emerald-700 font-bold hover:underline cursor-pointer"
                  >
                    View All Orders ({orders.length}) →
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-zinc-100 text-zinc-400 font-bold">
                        <th className="pb-3">Order ID</th>
                        <th className="pb-3">Customer</th>
                        <th className="pb-3">District</th>
                        <th className="pb-3">Total</th>
                        <th className="pb-3">Status</th>
                        <th className="pb-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-100 font-medium">
                      {recentOrders.map((ord) => (
                        <tr key={ord.id} className="hover:bg-zinc-50/80">
                          <td className="py-3 font-mono font-bold text-zinc-900">
                            {ord.order_number}
                          </td>
                          <td className="py-3">
                            <div className="font-bold text-zinc-900">{ord.customer_name}</div>
                            <div className="text-zinc-400">{ord.phone}</div>
                          </td>
                          <td className="py-3 text-zinc-600">{ord.district}</td>
                          <td className="py-3 font-extrabold text-zinc-900">
                            ৳{Number(ord.total).toLocaleString('en-BD')}
                          </td>
                          <td className="py-3">
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border ${getStatusBadgeClass(
                                ord.status
                              )}`}
                            >
                              {ord.status}
                            </span>
                          </td>
                          <td className="py-3 text-right">
                            <div className="flex items-center justify-end gap-1">
                              <button
                                onClick={() => {
                                  setEditingOrder(ord);
                                  setIsOrderModalOpen(true);
                                }}
                                className="text-xs font-bold text-zinc-700 hover:text-zinc-950 px-2 py-1 hover:bg-zinc-100 rounded-md cursor-pointer"
                              >
                                Edit
                              </button>
                              <button
                                onClick={() => setSelectedOrderForInvoice(ord)}
                                title="Print Invoice"
                                className="text-xs font-bold text-zinc-500 hover:text-zinc-950 p-1 hover:bg-zinc-100 rounded-md cursor-pointer"
                              >
                                <Printer className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                      {recentOrders.length === 0 && (
                        <tr>
                          <td colSpan={6} className="py-8 text-center text-zinc-400">
                            No orders placed yet.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Best Selling Products */}
              <div className="bg-white rounded-2xl border border-zinc-200 shadow-xs p-5 space-y-4">
                <h3 className="font-extrabold text-base text-zinc-900">
                  Best Selling Items
                </h3>

                <div className="space-y-3">
                  {bestProducts.map((item, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-3 rounded-xl bg-zinc-50 border border-zinc-100"
                    >
                      <div className="min-w-0 pr-2">
                        <div className="font-bold text-xs text-zinc-900 truncate">
                          {item.name || item.product_name}
                        </div>
                        <div className="text-[11px] text-zinc-500">
                          {item.sku || 'SKU-00' + (idx + 1)} · {item.stock || 10} in stock
                        </div>
                      </div>
                      <div className="text-xs font-black text-emerald-700 shrink-0">
                        ৳{Number(item.selling_price || 0).toLocaleString('en-BD')}
                      </div>
                    </div>
                  ))}
                  {bestProducts.length === 0 && (
                    <div className="py-8 text-center text-zinc-400 text-xs">
                      No sales recorded yet.
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ====================================================
            2. TAB: PRODUCTS MANAGEMENT
        ==================================================== */}
        {currentTab === 'products' && (
          <div className="space-y-6 animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl font-black text-zinc-900 tracking-tight">
                  Products & Inventory Management
                </h2>
                <p className="text-xs text-zinc-500">
                  Manage inventory, buying costs, selling prices, discounts, SKU and SEO tags
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsManageTypesModalOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white border border-zinc-200 text-zinc-800 font-bold text-xs sm:text-sm hover:bg-zinc-50 shadow-xs transition-all cursor-pointer"
                  title="Manage custom product types (প্রোডাক্ট টাইপসমূহ)"
                >
                  <SettingsIcon className="w-4 h-4 text-zinc-600" />
                  <span>Product Types ({availableProductTypes.length})</span>
                </button>
                <button
                  onClick={() => {
                    setEditingProduct({
                      name: '',
                      category: 'Smart Gadgets',
                      sub_category: '',
                      child_category: '',
                      product_type: availableProductTypes[0] || 'Standard Product',
                      sku: '',
                      buying_price: 0,
                      selling_price: 0,
                      discount: 0,
                      stock: 10,
                      badge: 'NEW',
                      image_url: '',
                      images: [],
                      colors: [],
                      product_link: '',
                      description: '',
                      featured: 0,
                      active: 1,
                      meta_title: '',
                      meta_description: '',
                      meta_keywords: '',
                      slug: '',
                      brand: 'Maxora',
                      og_image: '',
                    });
                    setProductModalTab('general');
                    setIsProductModalOpen(true);
                  }}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-zinc-950 text-white font-bold text-xs sm:text-sm hover:bg-zinc-800 shadow-md transition-all cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New Product</span>
                </button>
              </div>
            </div>

            {/* Product Filters Toolbar */}
            <div className="bg-white p-4 rounded-2xl border border-zinc-200 shadow-xs flex flex-wrap gap-3 items-center justify-between">
              <div className="relative flex-1 min-w-[240px]">
                <input
                  type="text"
                  placeholder="Search product by name, SKU, color or category..."
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  className="w-full bg-zinc-50 focus:bg-white text-zinc-900 text-xs sm:text-sm pl-9 pr-3 py-2 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                />
                <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-2.5" />
              </div>

              <div className="flex items-center gap-2">
                {/* 4-Tier Interactive Category Hierarchy Trigger & Panel */}
                <div className="relative">
                  <button
                    type="button"
                    id="admin-hierarchy-trigger"
                    data-hierarchy-trigger="true"
                    onClick={() => setIsHierarchyNavOpen(!isHierarchyNavOpen)}
                    className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold border transition-all cursor-pointer shadow-xs ${
                      isHierarchyNavOpen || currentTaxonomyFilter.category
                        ? 'bg-zinc-950 text-white border-zinc-950 shadow-md'
                        : 'bg-zinc-50 hover:bg-zinc-100 text-zinc-800 border-zinc-300'
                    }`}
                    title="Open 4-tier Category Hierarchy to browse, filter, or edit products"
                  >
                    <Layers
                      className={`w-4 h-4 ${
                        isHierarchyNavOpen || currentTaxonomyFilter.category
                          ? 'text-emerald-400'
                          : 'text-emerald-600'
                      }`}
                    />
                    <span className="truncate max-w-[130px]">
                      {currentTaxonomyFilter.childCategory ||
                        currentTaxonomyFilter.productType ||
                        currentTaxonomyFilter.subCategory ||
                        currentTaxonomyFilter.category ||
                        'Category Hierarchy'}
                    </span>
                    {currentTaxonomyFilter.category && (
                      <span
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setCurrentTaxonomyFilter({});
                          setProductCategoryFilter('');
                        }}
                        className="p-0.5 hover:bg-zinc-800 rounded-full text-zinc-400 hover:text-white"
                        title="Clear hierarchy filter"
                      >
                        <X className="w-3 h-3" />
                      </span>
                    )}
                  </button>

                  {/* 4-Level Category Hierarchy Menu */}
                  {isHierarchyNavOpen && (
                    <CategoryHierarchyMenu
                      isOpen={isHierarchyNavOpen}
                      onClose={() => setIsHierarchyNavOpen(false)}
                      taxonomy={taxonomy}
                      currentFilter={currentTaxonomyFilter}
                      onSelectTaxonomy={(filter) => {
                        setCurrentTaxonomyFilter(filter);
                        if (filter.category) {
                          setProductCategoryFilter(filter.category);
                        } else {
                          setProductCategoryFilter('');
                        }
                      }}
                      products={products}
                      onSelectProduct={(prod) => {
                        setEditingProduct(prod);
                        setProductModalTab('general');
                        setIsProductModalOpen(true);
                      }}
                      mode="admin"
                    />
                  )}
                </div>

                <select
                  value={productCategoryFilter}
                  onChange={(e) => setProductCategoryFilter(e.target.value)}
                  className="bg-zinc-50 border border-zinc-300 text-xs sm:text-sm font-semibold rounded-xl px-3 py-2 text-zinc-700"
                >
                  <option value="">All Categories</option>
                  {categoriesList.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>

                <select
                  value={productBrandFilter}
                  onChange={(e) => setProductBrandFilter(e.target.value)}
                  className="bg-zinc-50 border border-zinc-300 text-xs sm:text-sm font-semibold rounded-xl px-3 py-2 text-zinc-700"
                >
                  <option value="">All Brands ({brandsListFromProducts.length})</option>
                  {brandsListFromProducts.map((b) => (
                    <option key={b} value={b}>
                      {b}
                    </option>
                  ))}
                </select>

                <select
                  value={productTypeFilter}
                  onChange={(e) => setProductTypeFilter(e.target.value)}
                  className="bg-zinc-50 border border-zinc-300 text-xs sm:text-sm font-semibold rounded-xl px-3 py-2 text-zinc-700"
                >
                  <option value="">All Types ({availableProductTypes.length})</option>
                  {availableProductTypes.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>

                <select
                  value={productStatusFilter}
                  onChange={(e) => setProductStatusFilter(e.target.value)}
                  className="bg-zinc-50 border border-zinc-300 text-xs sm:text-sm font-semibold rounded-xl px-3 py-2 text-zinc-700"
                >
                  <option value="all">All Statuses</option>
                  <option value="active">Active Only</option>
                  <option value="hidden">Hidden Only</option>
                </select>

                <button
                  onClick={() => loadProducts()}
                  className="p-2 border border-zinc-300 rounded-xl bg-zinc-50 hover:bg-zinc-100 text-zinc-700 cursor-pointer"
                  title="Reload Products"
                >
                  <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                </button>
              </div>
            </div>

            {/* Products Table */}
            <div className="bg-white rounded-2xl border border-zinc-200 shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-zinc-50 border-b border-zinc-200 text-zinc-500 font-bold uppercase tracking-wider">
                    <tr>
                      <th className="p-4">Item</th>
                      <th className="p-4">Brand</th>
                      <th className="p-4">Category</th>
                      <th className="p-4">SKU</th>
                      <th className="p-4">Buying Price</th>
                      <th className="p-4">Selling Price</th>
                      <th className="p-4">Discount</th>
                      <th className="p-4">Stock</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-100 font-medium">
                    {filteredProducts.map((p) => {
                      return (
                        <tr key={p.id} className="hover:bg-zinc-50/70">
                          <td className="p-4">
                            <div className="flex items-center gap-3">
                              <img
                                src={p.image_url || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80'}
                                alt={p.name}
                                className="w-10 h-10 rounded-lg object-cover bg-zinc-100 shrink-0 border border-zinc-200"
                              />
                              <div>
                                <div className="font-bold text-zinc-900 line-clamp-1">{p.name}</div>
                                {p.badge && (
                                  <span className="inline-block text-[9px] font-extrabold uppercase px-1.5 py-0.2 bg-emerald-100 text-emerald-800 rounded">
                                    {p.badge}
                                  </span>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="p-4">
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-800 border border-amber-500/20 text-xs font-bold whitespace-nowrap">
                              <Tag className="w-3 h-3 text-amber-600" />
                              <span>{p.brand || 'Other'}</span>
                            </span>
                          </td>
                          <td className="p-4">
                            <div className="flex flex-col gap-0.5 min-w-[130px]">
                              <span className="font-bold text-zinc-900 text-xs">{p.category}</span>
                              {(p.sub_category || p.child_category) && (
                                <span className="text-[11px] text-zinc-500 font-medium leading-tight">
                                  {[p.sub_category, p.child_category].filter(Boolean).join(' › ')}
                                </span>
                              )}
                              {p.product_type && (
                                <span className="inline-block mt-0.5 px-1.5 py-0.5 bg-zinc-100 text-zinc-700 rounded text-[10px] font-semibold w-fit border border-zinc-200">
                                  {p.product_type}
                                </span>
                              )}
                              {Array.isArray(p.colors) && p.colors.length > 0 && (
                                <div className="flex items-center gap-1.5 mt-1">
                                  <div className="flex items-center -space-x-1">
                                    {p.colors.slice(0, 4).map((c, i) => (
                                      <span
                                        key={i}
                                        title={`${c.name} (Stock: ${c.stock ?? 'Available'})`}
                                        className="w-3.5 h-3.5 rounded-full border-2 border-white shadow-2xs inline-block"
                                        style={{ backgroundColor: c.code || '#71717a' }}
                                      />
                                    ))}
                                  </div>
                                  <span className="text-[10px] font-bold text-purple-700 bg-purple-50 px-1.5 py-0.2 rounded border border-purple-200/70">
                                    {p.colors.length} {p.colors.length > 1 ? 'Colors' : 'Color'}
                                  </span>
                                </div>
                              )}
                              {p.meta_keywords && (
                                <span
                                  className="inline-flex items-center gap-1 mt-0.5 px-1.5 py-0.5 bg-emerald-50 text-emerald-700 rounded text-[9px] font-bold border border-emerald-200/70 w-fit"
                                  title={`Google SEO: ${p.meta_keywords}`}
                                >
                                  <Tag className="w-2.5 h-2.5" />
                                  <span>SEO ({p.meta_keywords.split(',').filter((k: string) => k.trim()).length})</span>
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-4 font-mono text-zinc-500">{p.sku || '-'}</td>
                          <td className="p-4 text-zinc-600 font-semibold">
                            ৳{Number(p.buying_price || 0).toLocaleString('en-BD')}
                          </td>
                          <td className="p-4 font-bold text-zinc-900">
                            ৳{Number(p.selling_price).toLocaleString('en-BD')}
                          </td>
                          <td className="p-4 text-rose-600">
                            {Number(p.discount || 0) > 0 ? `৳${Number(p.discount).toLocaleString('en-BD')}` : '-'}
                          </td>
                          <td className="p-4">
                            <span
                              className={`font-bold ${
                                Number(p.stock) <= 0
                                    ? 'text-rose-600'
                                    : Number(p.stock) <= 5
                                    ? 'text-amber-600'
                                    : 'text-emerald-700'
                              }`}
                            >
                              {p.stock} units
                            </span>
                          </td>
                          <td className="p-4">
                            <div className="flex flex-col gap-1.5 items-start">
                              <span
                                className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                                  p.active !== 0
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : 'bg-zinc-200 text-zinc-600'
                                }`}
                              >
                                {p.active !== 0 ? 'Active' : 'Hidden'}
                              </span>

                              <div className="flex flex-wrap gap-1 max-w-[170px]">
                                <button
                                  type="button"
                                  onClick={() => handleToggleFeatured(p)}
                                  title="Toggle Featured status for Homepage Hero"
                                  className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold transition-all cursor-pointer ${
                                    p.featured && p.featured !== 0
                                      ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                      : 'bg-zinc-100 text-zinc-400 hover:bg-zinc-200'
                                  }`}
                                >
                                  <span>{p.featured && p.featured !== 0 ? '★ Hero' : '☆ Hero'}</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleToggleHotDeal(p)}
                                  title="Toggle Hot Deal on Homepage"
                                  className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold transition-all cursor-pointer ${
                                    p.is_hot_deal
                                      ? 'bg-rose-100 text-rose-900 border border-rose-300'
                                      : 'bg-zinc-100 text-zinc-400 hover:bg-zinc-200'
                                  }`}
                                >
                                  <span>{p.is_hot_deal ? '🔥 Hot' : '🔥 Off'}</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleToggleFlashSale(p)}
                                  title="Toggle Flash Sale on Homepage"
                                  className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold transition-all cursor-pointer ${
                                    p.is_flash_sale
                                      ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                      : 'bg-zinc-100 text-zinc-400 hover:bg-zinc-200'
                                  }`}
                                >
                                  <span>{p.is_flash_sale ? '⚡ Flash' : '⚡ Off'}</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleToggleNewArrival(p)}
                                  title="Toggle New Arrival on Homepage"
                                  className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold transition-all cursor-pointer ${
                                    p.is_new_arrival
                                      ? 'bg-blue-100 text-blue-900 border border-blue-300'
                                      : 'bg-zinc-100 text-zinc-400 hover:bg-zinc-200'
                                  }`}
                                >
                                  <span>{p.is_new_arrival ? '🆕 New' : '🆕 Off'}</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleToggleBestSeller(p)}
                                  title="Toggle Best Seller on Homepage"
                                  className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold transition-all cursor-pointer ${
                                    p.is_best_seller
                                      ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                                      : 'bg-zinc-100 text-zinc-400 hover:bg-zinc-200'
                                  }`}
                                >
                                  <span>{p.is_best_seller ? '⭐ Best' : '⭐ Off'}</span>
                                </button>
                              </div>
                            </div>
                          </td>
                          <td className="p-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => {
                                  const directLink = p.product_link || `${window.location.origin}/?product=${p.id}`;
                                  navigator.clipboard.writeText(directLink);
                                  showToast('Product link copied to clipboard! (প্রোডাক্ট লিংক কপি হয়েছে)', 'success');
                                }}
                                className="p-1.5 text-zinc-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                                title="Copy Product Direct Link (ক্লিক করে সরাসরি প্রোডাক্টের লিংক কপি করুন)"
                              >
                                <Link2 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => {
                                  setEditingProduct({
                                    ...p,
                                    sub_category: p.sub_category || '',
                                    child_category: p.child_category || '',
                                    product_type: p.product_type || availableProductTypes[0] || 'Standard Product',
                                    product_link: p.product_link || '',
                                    images: p.images || [],
                                    colors: p.colors || [],
                                    meta_title: p.meta_title || '',
                                    meta_description: p.meta_description || '',
                                    meta_keywords: p.meta_keywords || '',
                                    slug: p.slug || (p.name ? p.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') : ''),
                                    brand: p.brand || 'Maxora',
                                    og_image: p.og_image || p.image_url || '',
                                  });
                                  setProductModalTab('variants');
                                  setIsProductModalOpen(true);
                                }}
                                className={`px-2 py-1 ${
                                  p.colors && p.colors.length > 0
                                    ? 'bg-purple-50 text-purple-700 hover:bg-purple-100 border border-purple-200/80'
                                    : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
                                } rounded-lg text-xs font-bold transition-colors inline-flex items-center gap-1 cursor-pointer`}
                                title={p.colors && p.colors.length > 0 ? `${p.colors.length} Colors: ${p.colors.map(c => c.name).join(', ')}` : 'Add color variants for this product (কালার ভ্যারিয়েন্ট যোগ করুন)'}
                              >
                                <Palette className="w-3.5 h-3.5" />
                                <span>Colors {p.colors && p.colors.length > 0 ? `(${p.colors.length})` : ''}</span>
                              </button>
                              <button
                                onClick={() => {
                                  setEditingProduct({
                                    ...p,
                                    sub_category: p.sub_category || '',
                                    child_category: p.child_category || '',
                                    product_type: p.product_type || availableProductTypes[0] || 'Standard Product',
                                    product_link: p.product_link || '',
                                    images: p.images || [],
                                    colors: p.colors || [],
                                    meta_title: p.meta_title || '',
                                    meta_description: p.meta_description || '',
                                    meta_keywords: p.meta_keywords || '',
                                    slug: p.slug || (p.name ? p.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') : ''),
                                    brand: p.brand || 'Maxora',
                                    og_image: p.og_image || p.image_url || '',
                                  });
                                  setProductModalTab('seo');
                                  setIsProductModalOpen(true);
                                }}
                                className={`px-2 py-1 ${
                                  p.meta_keywords
                                    ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200/80'
                                    : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
                                } rounded-lg text-xs font-bold transition-colors inline-flex items-center gap-1 cursor-pointer`}
                                title={p.meta_keywords ? `Google SEO Keywords: ${p.meta_keywords}` : 'Configure Google SEO & Keywords'}
                              >
                                <Globe className="w-3.5 h-3.5" />
                                <span>SEO {p.meta_keywords ? '✓' : ''}</span>
                              </button>
                              <button
                                onClick={() => {
                                  setEditingProduct({
                                    ...p,
                                    sub_category: p.sub_category || '',
                                    child_category: p.child_category || '',
                                    product_type: p.product_type || availableProductTypes[0] || 'Standard Product',
                                    product_link: p.product_link || '',
                                    images: p.images || [],
                                    colors: p.colors || [],
                                    meta_title: p.meta_title || '',
                                    meta_description: p.meta_description || '',
                                    meta_keywords: p.meta_keywords || '',
                                    slug: p.slug || (p.name ? p.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') : ''),
                                    brand: p.brand || 'Maxora',
                                    og_image: p.og_image || p.image_url || '',
                                  });
                                  setProductModalTab('general');
                                  setIsProductModalOpen(true);
                                }}
                                className="p-1.5 text-zinc-600 hover:text-zinc-950 hover:bg-zinc-100 rounded-lg transition-colors cursor-pointer"
                                title="Edit Product"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteProduct(p.id, p.name)}
                                className="p-1.5 text-zinc-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                title="Delete Product"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                    {filteredProducts.length === 0 && (
                      <tr>
                        <td colSpan={9} className="p-8 text-center text-zinc-400">
                          No products found matching filters.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ====================================================
            CATEGORIES & SUBCATEGORIES MANAGEMENT
        ==================================================== */}
        {currentTab === 'categories' && (
          <div className="space-y-6 animate-fade-in">
            <AdminCategories
              password={password}
              products={products}
              onUpdated={() => {
                loadCategories();
                loadProducts();
                onSettingsUpdated();
              }}
              onSelectProduct={(prod) => {
                setEditingProduct({
                  ...prod,
                  sub_category: prod.sub_category || '',
                  child_category: prod.child_category || '',
                  product_type: prod.product_type || availableProductTypes[0] || 'Standard Product',
                  product_link: prod.product_link || '',
                  images: prod.images || [],
                  colors: prod.colors || [],
                  meta_title: prod.meta_title || '',
                  meta_description: prod.meta_description || '',
                  meta_keywords: prod.meta_keywords || '',
                  slug: prod.slug || (prod.name ? prod.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') : ''),
                  brand: prod.brand || 'Maxora',
                  og_image: prod.og_image || prod.image_url || '',
                });
                setProductModalTab('general');
                setIsProductModalOpen(true);
              }}
            />
          </div>
        )}

        {/* ====================================================
            3. TAB: ORDERS MANAGEMENT
        ==================================================== */}
        {currentTab === 'orders' && (
          <div className="space-y-6 animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-2xl font-black text-zinc-900 tracking-tight">
                    Orders Management
                  </h2>
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    Live Cloud Sync ({orders.length} orders)
                  </span>
                </div>
                <p className="text-xs text-zinc-500 mt-0.5">
                  Live real-time synced with Firebase database. Process orders, print slips & update status.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={async () => {
                    setLoading(true);
                    try {
                      const list = await storeService.getAllAdminOrders(orderStatusFilter, password);
                      setOrders(list);
                      if (list.length > 0) {
                        showToast(`Successfully synced ${list.length} orders!`, 'success');
                      } else {
                        showToast('Sync complete: No orders yet.', 'info');
                      }
                    } catch (err: any) {
                      console.error('Fetch orders error:', err);
                      showToast('Sync error: ' + (err?.message || 'Check connection'), 'error');
                    } finally {
                      setLoading(false);
                    }
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-50 border border-emerald-300 text-xs font-bold text-emerald-800 hover:bg-emerald-100 shadow-xs cursor-pointer"
                  title="Fetch all orders from server and cloud database"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                  <span>Sync Orders ({orders.length})</span>
                </button>
                <button
                  onClick={handlePurgeDemoData}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-50 border border-rose-200 text-xs font-bold text-rose-700 hover:bg-rose-100 shadow-xs cursor-pointer"
                  title="Purge legacy fake orders and refresh cache"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Purge Cache</span>
                </button>
              </div>
            </div>

            {/* Orders Filter Toolbar */}
            <div className="bg-white p-4 rounded-2xl border border-zinc-200 shadow-xs flex flex-wrap gap-3 items-center justify-between">
              <div className="relative flex-1 min-w-[240px]">
                <input
                  type="text"
                  placeholder="Search order #, customer name, mobile number, district or thana..."
                  value={orderSearch}
                  onChange={(e) => setOrderSearch(e.target.value)}
                  className="w-full bg-zinc-50 focus:bg-white text-zinc-900 text-xs sm:text-sm pl-9 pr-3 py-2 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                />
                <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-2.5" />
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={orderStatusFilter}
                  onChange={(e) => setOrderStatusFilter(e.target.value)}
                  className="bg-zinc-50 border border-zinc-300 text-xs sm:text-sm font-semibold rounded-xl px-3 py-2 text-zinc-700"
                >
                  <option value="">All Statuses</option>
                  <option value="Pending">Pending</option>
                  <option value="Confirmed">Confirmed</option>
                  <option value="Processing">Processing</option>
                  <option value="Shipped">Shipped</option>
                  <option value="Delivered">Delivered</option>
                  <option value="Cancelled">Cancelled</option>
                  <option value="Returned">Returned</option>
                </select>

                <select
                  value={orderDateFilter}
                  onChange={(e) => setOrderDateFilter(e.target.value as any)}
                  className="bg-zinc-50 border border-zinc-300 text-xs sm:text-sm font-semibold rounded-xl px-3 py-2 text-zinc-700"
                >
                  <option value="all">All Dates</option>
                  <option value="today">Today Only</option>
                  <option value="this_month">This Month</option>
                </select>
              </div>
            </div>

            {/* Orders Table */}
            <div className="bg-white rounded-2xl border border-zinc-200 shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-zinc-50 border-b border-zinc-200 text-zinc-500 font-bold uppercase tracking-wider">
                    <tr>
                      <th className="p-4">Order ID & Date</th>
                      <th className="p-4">Customer Details</th>
                      <th className="p-4">Address / District</th>
                      <th className="p-4">Delivery Charge</th>
                      <th className="p-4">Total Amount</th>
                      <th className="p-4">Status Changer</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-100 font-medium">
                    {filteredOrders.map((ord) => (
                      <tr key={ord.id} className="hover:bg-zinc-50/70">
                        <td className="p-4">
                          <div className="font-mono font-bold text-zinc-950 text-sm">
                            {ord.order_number}
                          </div>
                          <div className="text-[11px] text-zinc-400">
                            {new Date(ord.created_at).toLocaleDateString('en-BD', { year: 'numeric', month: 'short', day: 'numeric' })}
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="font-bold text-zinc-900">{ord.customer_name}</div>
                          <div className="flex items-center gap-2 mt-0.5">
                            <a
                              href={`tel:${ord.phone}`}
                              className="text-zinc-700 hover:text-emerald-600 font-mono flex items-center gap-1 font-semibold"
                            >
                              <Phone className="w-3 h-3 text-emerald-600" />
                              <span>{ord.phone}</span>
                            </a>
                            <a
                              href={`https://wa.me/${ord.phone.replace(/[^0-9]/g, '')}`}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[10px] text-emerald-600 hover:underline font-bold"
                            >
                              WhatsApp
                            </a>
                          </div>
                          {ord.alt_phone && (
                            <div className="text-[10px] text-zinc-400">Alt: {ord.alt_phone}</div>
                          )}
                        </td>
                        <td className="p-4">
                          <div className="font-semibold text-zinc-900">{ord.district}</div>
                          <div className="text-zinc-500 text-[11px]">{ord.area}</div>
                          <div className="text-[10px] text-zinc-400 truncate max-w-[180px]" title={ord.address}>
                            {ord.address}
                          </div>
                        </td>
                        <td className="p-4 text-zinc-600 font-semibold">
                          ৳{Number(ord.delivery_charge || 0).toLocaleString('en-BD')}
                        </td>
                        <td className="p-4">
                          <div className="font-black text-zinc-950 text-sm">
                            ৳{Number(ord.total).toLocaleString('en-BD')}
                          </div>
                          <div className="text-[10px] text-emerald-700 font-semibold">
                            Cash on Delivery
                          </div>
                        </td>
                        <td className="p-4">
                          <select
                            value={ord.status}
                            onChange={(e) =>
                              handleQuickStatusUpdate(ord.id, e.target.value as OrderStatus)
                            }
                            className={`px-2.5 py-1 rounded-lg text-xs font-bold border cursor-pointer ${getStatusBadgeClass(
                              ord.status
                            )}`}
                          >
                            <option value="Pending">Pending</option>
                            <option value="Confirmed">Confirmed</option>
                            <option value="Processing">Processing</option>
                            <option value="Shipped">Shipped</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Cancelled">Cancelled</option>
                            <option value="Returned">Returned</option>
                          </select>
                        </td>
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => setSelectedOrderForInvoice(ord)}
                              title="Print Invoice / Packing Slip"
                              className="p-1.5 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-zinc-800 transition-colors cursor-pointer"
                            >
                              <Printer className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => {
                                setEditingOrder(ord);
                                setIsOrderModalOpen(true);
                              }}
                              className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-white font-bold text-xs transition-colors cursor-pointer"
                            >
                              Edit
                            </button>
                            <button
                              onClick={() => handleDeleteOrder(ord.id, ord.order_number)}
                              title="Delete this order"
                              className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {filteredOrders.length === 0 && (
                      <tr>
                        <td colSpan={7} className="p-8 text-center text-zinc-400">
                          No orders found matching criteria.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ====================================================
            4. TAB: CUSTOMERS
        ==================================================== */}
        {currentTab === 'customers' && (
          <div className="space-y-6 animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl font-black text-zinc-900 tracking-tight">
                  Customers Directory
                </h2>
                <p className="text-xs text-zinc-500">
                  Customer profiles, contact numbers, order histories and lifetime purchase value
                </p>
              </div>

              <button
                onClick={() => loadCustomers()}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white border border-zinc-200 text-xs font-bold text-zinc-700 hover:bg-zinc-50 shadow-xs cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                <span>Refresh Customers</span>
              </button>
            </div>

            {/* Search Customers */}
            <div className="bg-white p-4 rounded-2xl border border-zinc-200 shadow-xs">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search customer by name, phone number, district or thana..."
                  value={customerSearch}
                  onChange={(e) => setCustomerSearch(e.target.value)}
                  className="w-full bg-zinc-50 focus:bg-white text-zinc-900 text-xs sm:text-sm pl-9 pr-3 py-2 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                />
                <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-2.5" />
              </div>
            </div>

            {/* Customers Table */}
            <div className="bg-white rounded-2xl border border-zinc-200 shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-zinc-50 border-b border-zinc-200 text-zinc-500 font-bold uppercase tracking-wider">
                    <tr>
                      <th className="p-4">Customer Name</th>
                      <th className="p-4">Mobile Number</th>
                      <th className="p-4">District & Thana</th>
                      <th className="p-4">Total Orders</th>
                      <th className="p-4 text-right">Lifetime Spent</th>
                      <th className="p-4 text-right">Order History</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-100 font-medium">
                    {filteredCustomers.map((c) => (
                      <tr key={c.id} className="hover:bg-zinc-50/70">
                        <td className="p-4">
                          <div className="font-bold text-zinc-900">{c.name}</div>
                          {c.email && <div className="text-[11px] text-zinc-400">{c.email}</div>}
                        </td>
                        <td className="p-4 font-mono font-semibold text-zinc-800">
                          <div className="flex items-center gap-2">
                            <span>{c.phone}</span>
                            <a
                              href={`https://wa.me/${c.phone.replace(/[^0-9]/g, '')}`}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[10px] text-emerald-600 hover:underline font-bold"
                            >
                              WhatsApp
                            </a>
                          </div>
                          {c.alt_phone && (
                            <div className="text-[10px] text-zinc-400">Alt: {c.alt_phone}</div>
                          )}
                        </td>
                        <td className="p-4">
                          <div className="font-semibold text-zinc-900">{c.district || 'Bangladesh'}</div>
                          <div className="text-zinc-500 text-[11px]">{c.area || '-'}</div>
                        </td>
                        <td className="p-4">
                          <span className="px-2.5 py-1 rounded-full bg-zinc-100 text-zinc-800 font-bold text-xs">
                            {c.total_orders || 1} orders
                          </span>
                        </td>
                        <td className="p-4 text-right font-black text-emerald-700 text-sm">
                          ৳{Number(c.total_spent || 0).toLocaleString('en-BD')}
                        </td>
                        <td className="p-4 text-right">
                          <button
                            onClick={() => setSelectedCustomerForHistory(c)}
                            className="px-3 py-1.5 bg-zinc-100 hover:bg-zinc-900 hover:text-white text-zinc-800 rounded-xl font-bold text-xs transition-colors cursor-pointer"
                          >
                            View Past Orders
                          </button>
                        </td>
                      </tr>
                    ))}
                    {filteredCustomers.length === 0 && (
                      <tr>
                        <td colSpan={6} className="p-8 text-center text-zinc-400">
                          No customer profiles found.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ====================================================
            4b. TAB: BRAND MANAGEMENT
        ==================================================== */}
        {currentTab === 'brands' && (
          <div className="space-y-6 animate-fade-in">
            <AdminBrands
              password={password}
              products={products}
              onUpdated={() => {
                loadProducts(password);
                loadBrands();
              }}
              onFilterByBrand={(brandName) => {
                setProductBrandFilter(brandName);
                handleTabChange('products');
              }}
            />
          </div>
        )}

        {/* ====================================================
            5. TAB: STORE SETTINGS
        ==================================================== */}
        {currentTab === 'settings' && (
          <div className="max-w-3xl space-y-6 animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl font-black text-zinc-900 tracking-tight">
                  Store & Delivery Settings
                </h2>
                <p className="text-xs text-zinc-500">
                  Manage branding, hotline, delivery rates, Facebook/Google Ads pixels & Google SEO
                </p>
              </div>

              {/* Settings Sub-tabs */}
              <div className="flex items-center gap-1 bg-zinc-200/80 p-1 rounded-2xl flex-wrap">
                <button
                  type="button"
                  onClick={() => setSettingsSubTab('general')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    settingsSubTab === 'general'
                      ? 'bg-white text-zinc-950 shadow-xs font-black'
                      : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                >
                  🏢 Store & Delivery
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSettingsSubTab('categories');
                    loadCategories();
                    loadProducts(password);
                  }}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                    settingsSubTab === 'categories'
                      ? 'bg-white text-zinc-950 shadow-xs font-black'
                      : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                >
                  <FolderTree className="w-3.5 h-3.5 text-emerald-600" />
                  Categories & Status
                  {dbCategories.length > 0 && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-zinc-200 text-zinc-800 font-extrabold">
                      {dbCategories.length}
                    </span>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setSettingsSubTab('marketing')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                    settingsSubTab === 'marketing'
                      ? 'bg-white text-zinc-950 shadow-xs font-black'
                      : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                >
                  <Megaphone className="w-3.5 h-3.5 text-blue-600" />
                  Marketing & Pixels
                </button>
              </div>
            </div>

            {/* Settings Sub-tab: Categories */}
            {settingsSubTab === 'categories' ? (
              <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-xs space-y-5 animate-fade-in">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-base font-black text-zinc-900 flex items-center gap-2">
                      <FolderTree className="w-5 h-5 text-emerald-600" />
                      <span>Categories Management & Status</span>
                    </h3>
                    <p className="text-xs text-zinc-500">
                      Edit category names, slugs, or toggle active/hidden status. Updates persist directly to Firestore.
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => loadCategories()}
                      title="Refresh categories from Firestore"
                      className="p-2 rounded-xl border border-zinc-200 hover:bg-zinc-100 text-zinc-600 transition-colors cursor-pointer"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleTabChange('categories')}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-800 text-xs font-bold transition-all cursor-pointer"
                      title="Open full taxonomy manager with Subcategories, Product Types & Child Categories"
                    >
                      <Layers className="w-4 h-4 text-emerald-600" />
                      <span>Full Hierarchy Tree</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setCategoryToEdit({
                          id: `cat-${Date.now()}`,
                          name: '',
                          slug: '',
                          active: 1,
                          display_order: dbCategories.length + 1,
                        });
                        setIsCategoryEditModalOpen(true);
                      }}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Category</span>
                    </button>
                  </div>
                </div>

                {/* Search categories bar */}
                <div className="relative">
                  <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search categories by name or slug..."
                    value={categorySearchInSettings}
                    onChange={(e) => setCategorySearchInSettings(e.target.value)}
                    className="w-full pl-9 pr-4 py-2.5 bg-zinc-50 text-xs sm:text-sm rounded-xl border border-zinc-200 focus:outline-none focus:border-zinc-900"
                  />
                </div>

                {/* Category Items List */}
                {filteredCategoriesInSettings.length === 0 ? (
                  <div className="p-8 bg-zinc-50 rounded-2xl border border-dashed border-zinc-300 text-center">
                    <FolderTree className="w-10 h-10 text-zinc-300 mx-auto mb-2" />
                    <p className="text-xs sm:text-sm font-bold text-zinc-700">No categories match your search</p>
                    <button
                      type="button"
                      onClick={() => {
                        setCategorySearchInSettings('');
                        loadCategories();
                      }}
                      className="mt-2 text-xs text-emerald-600 font-bold hover:underline"
                    >
                      Reset Filter
                    </button>
                  </div>
                ) : (
                  <div className="bg-zinc-50 rounded-2xl border border-zinc-200 overflow-hidden divide-y divide-zinc-200">
                    {filteredCategoriesInSettings.map((cat) => {
                      const catProdCount = products.filter((p) => isProductInCategory(p, cat)).length;
                      const isActive = cat.active !== 0;

                      return (
                        <div
                          key={cat.id || cat.slug}
                          className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-zinc-100/80 transition-colors"
                        >
                          <div className="flex items-center gap-3.5 min-w-0">
                            <div className="w-10 h-10 rounded-2xl bg-white border border-zinc-200 text-zinc-800 flex items-center justify-center shrink-0 shadow-xs">
                              <FolderTree className="w-5 h-5 text-emerald-600" />
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <h4 className="text-sm font-black text-zinc-900">
                                  {cat.name}
                                </h4>
                                <span
                                  className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${
                                    isActive
                                      ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                                      : 'bg-zinc-200 text-zinc-600 border-zinc-300'
                                  }`}
                                >
                                  <span
                                    className={`w-1.5 h-1.5 rounded-full ${
                                      isActive ? 'bg-emerald-500' : 'bg-zinc-400'
                                    }`}
                                  />
                                  {isActive ? 'Active (প্রদর্শিত)' : 'Hidden (লুকানো)'}
                                </span>
                              </div>
                              <div className="flex items-center gap-2.5 text-xs text-zinc-500 mt-0.5 flex-wrap">
                                <span className="font-mono text-zinc-600">/{cat.slug || generateSlug(cat.name)}</span>
                                <span>•</span>
                                <span className="font-semibold text-zinc-700">
                                  {catProdCount} {catProdCount === 1 ? 'Product' : 'Products'}
                                </span>
                                {cat.display_order && (
                                  <>
                                    <span>•</span>
                                    <span className="text-zinc-400">Order: {cat.display_order}</span>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                            <button
                              type="button"
                              onClick={() => handleToggleCategoryStatus(cat)}
                              title={isActive ? 'Click to hide category from website' : 'Click to show category on website'}
                              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                                isActive
                                  ? 'bg-white hover:bg-zinc-100 text-zinc-700 border-zinc-300'
                                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-300'
                              }`}
                            >
                              {isActive ? 'Hide' : 'Activate'}
                            </button>
                            <button
                              type="button"
                              onClick={() => handleOpenCategoryEditModal(cat)}
                              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-zinc-900 hover:bg-emerald-600 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                              <span>Edit</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            ) : (
              <form onSubmit={handleSaveSettings} className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-xs space-y-5">
              {settingsSubTab === 'general' ? (
                <>
                  <div className="space-y-4">
                    <h3 className="text-xs font-black uppercase tracking-wider text-zinc-400">
                      Store Branding & Helpline
                    </h3>

                    {/* Store Logo & Header Branding Box */}
                    <div className="p-4 sm:p-5 bg-gradient-to-br from-zinc-50 to-zinc-100/70 rounded-2xl border border-zinc-200/90 space-y-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-200">
                        <div>
                          <h4 className="text-sm font-black text-zinc-900 flex items-center gap-2">
                            <ImageIcon className="w-4 h-4 text-emerald-600" />
                            <span>Store Logo & Header Branding (লোগো ও নাম)</span>
                          </h4>
                          <p className="text-xs text-zinc-500">
                            ওয়েবসাইটের হেডার, ইনভয়েস ও ফুটারে প্রদর্শিত লোগো ছবি এবং স্টোর নাম
                          </p>
                        </div>

                        {/* Live Header Simulation Preview */}
                        <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-xl border border-zinc-200 shadow-2xs">
                          <span className="text-[10px] font-bold text-zinc-400 uppercase">Live Preview:</span>
                          <div className="flex items-center gap-2">
                            {settingsForm.logo_url ? (
                              <img
                                src={settingsForm.logo_url}
                                alt="Logo Preview"
                                className="w-7 h-7 rounded-lg object-contain bg-zinc-50 border border-zinc-200"
                              />
                            ) : (
                              <div className="w-7 h-7 rounded-lg bg-zinc-950 text-white font-black text-xs flex items-center justify-center">
                                {(settingsForm.store_name?.trim() || 'M').charAt(0).toUpperCase()}
                              </div>
                            )}
                            <span className="text-xs font-black text-zinc-900 truncate max-w-[130px]">
                              {settingsForm.store_name || "Maxora Shop BD"}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Logo Controls */}
                      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-start">
                        {/* Current Logo Preview Box */}
                        <div className="md:col-span-4 flex flex-col items-center justify-center p-4 bg-white rounded-xl border border-zinc-200 text-center">
                          <span className="text-[11px] font-bold text-zinc-500 mb-2">Current Logo</span>
                          {settingsForm.logo_url ? (
                            <div className="relative group/logo">
                              <div className="w-20 h-20 rounded-2xl overflow-hidden bg-zinc-50 border-2 border-emerald-500/50 p-1 flex items-center justify-center shadow-xs">
                                <img
                                  src={settingsForm.logo_url}
                                  alt="Current Logo"
                                  className="w-full h-full object-contain"
                                />
                              </div>
                              <button
                                type="button"
                                onClick={() => {
                                  setSettingsForm({ ...settingsForm, logo_url: '' });
                                  showToast('লোগো সরানো হয়েছে। ডিফল্ট লেটার ব্যাজ দেখানো হবে।', 'info');
                                }}
                                title="Remove Logo (revert to letter badge)"
                                className="absolute -top-2 -right-2 p-1 bg-red-600 hover:bg-red-700 text-white rounded-full shadow-md transition-transform hover:scale-110 cursor-pointer"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ) : (
                            <div className="w-20 h-20 rounded-2xl bg-zinc-950 text-white flex flex-col items-center justify-center shadow-md">
                              <span className="text-3xl font-black">
                                {(settingsForm.store_name?.trim() || 'M').charAt(0).toUpperCase()}
                              </span>
                              <span className="text-[9px] text-zinc-400 font-medium mt-0.5">Letter Badge</span>
                            </div>
                          )}
                          <p className="text-[10px] text-zinc-400 mt-2">
                            {settingsForm.logo_url ? 'Custom image logo active' : 'Default letter badge active'}
                          </p>
                        </div>

                        {/* Upload & URL Inputs */}
                        <div className="md:col-span-8 space-y-3">
                          <div>
                            <label className="block text-xs font-bold text-zinc-700 mb-1">
                              Upload Logo File (লোগো ছবি আপলোড করুন)
                            </label>
                            <div className="flex items-center gap-2 flex-wrap">
                              <input
                                type="file"
                                accept="image/png,image/jpeg,image/webp,image/svg+xml"
                                id="logo-file-input"
                                className="hidden"
                                onChange={async (e) => {
                                  const file = e.target.files?.[0];
                                  if (!file) return;
                                  try {
                                    setLoading(true);
                                    const dataUrl = await compressAndReadImage(file);
                                    setSettingsForm(prev => ({ ...prev, logo_url: dataUrl }));
                                    showToast('লোগো ছবি আপলোড হয়েছে! নিচের "Save Settings" বাটনে চাপুন।', 'success');
                                  } catch (err: any) {
                                    showToast(err.message || 'লোগো ফাইল রিড করতে সমস্যা হয়েছে', 'error');
                                  } finally {
                                    setLoading(false);
                                    if (e.target) e.target.value = '';
                                  }
                                }}
                              />
                              <label
                                htmlFor="logo-file-input"
                                className="inline-flex items-center gap-2 px-4 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-white rounded-xl text-xs font-bold cursor-pointer transition-all shadow-xs"
                              >
                                <Upload className="w-4 h-4 text-emerald-400" />
                                <span>Choose Image From Device</span>
                              </label>

                              {settingsForm.logo_url && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setSettingsForm({ ...settingsForm, logo_url: '' });
                                    showToast('লোগো সরানো হয়েছে। ডিফল্ট লেটার ব্যাজ দেখানো হবে।', 'info');
                                  }}
                                  className="inline-flex items-center gap-1.5 px-3 py-2.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>Remove Logo</span>
                                </button>
                              )}
                            </div>
                            <span className="text-[10px] text-zinc-400 block mt-1">
                              PNG, JPG, WEBP বা SVG ফাইল (প্রস্তাবিত: স্কয়ার বা ট্রান্সপারেন্ট ব্যাকগ্রাউন্ড)
                            </span>
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-zinc-700 mb-1">
                              Or Paste Logo URL (অথবা অনলাইন ইমেজের লিংক দিন)
                            </label>
                            <div className="relative">
                              <Link2 className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                              <input
                                type="url"
                                placeholder="https://example.com/logo.png"
                                value={settingsForm.logo_url || ''}
                                onChange={(e) => setSettingsForm({ ...settingsForm, logo_url: e.target.value })}
                                className="w-full bg-white text-zinc-900 text-xs pl-8 pr-3 py-2.5 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Store Name & Helpline Row */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-zinc-700 mb-1">
                          Store Name (দোকান / ওয়েবসাইটের নাম)
                        </label>
                        <input
                          type="text"
                          value={settingsForm.store_name || ''}
                          onChange={(e) => setSettingsForm({ ...settingsForm, store_name: e.target.value })}
                          placeholder="Maxora Shop BD"
                          className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900 font-bold"
                        />
                        <span className="text-[10px] text-zinc-400 block mt-1">
                          লোগোর পাশে এই নামটি ওয়েবসাইটের হেডার ও ফুটারে দেখাবে
                        </span>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-zinc-700 mb-1">
                          Helpline Mobile Number
                        </label>
                        <input
                          type="text"
                          value={settingsForm.phone || ''}
                          onChange={(e) => setSettingsForm({ ...settingsForm, phone: e.target.value })}
                          placeholder="e.g. 01700-123456"
                          className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                        />
                      </div>
                    </div>

                    {/* Support Phone & WhatsApp */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-zinc-700 mb-1">
                          Helpline / Support Phone
                        </label>
                        <input
                          type="text"
                          value={settingsForm.phone || ''}
                          onChange={(e) => setSettingsForm({ ...settingsForm, phone: e.target.value })}
                          placeholder="e.g. 01700-123456"
                          className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-zinc-700 mb-1">
                          WhatsApp Number
                        </label>
                        <input
                          type="text"
                          value={settingsForm.whatsapp || ''}
                          onChange={(e) => setSettingsForm({ ...settingsForm, whatsapp: e.target.value })}
                          placeholder="e.g. +8801700123456"
                          className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                        />
                      </div>
                    </div>

                    {/* Social Media Channels (Facebook, Instagram, YouTube, TikTok) */}
                    <div className="p-4 sm:p-5 bg-gradient-to-br from-zinc-50 to-zinc-100/70 rounded-2xl border border-zinc-200/90 space-y-4">
                      <div>
                        <h4 className="text-sm font-black text-zinc-900 flex items-center gap-2">
                          <Share2 className="w-4 h-4 text-emerald-600" />
                          <span>Social Media Profiles (সোশ্যাল মিডিয়া পেজ ও লিংক)</span>
                        </h4>
                        <p className="text-xs text-zinc-500">
                          ওয়েবসাইটের ফুটারে ফেসবুক, ইনস্টাগ্রাম, ইউটিউব ও টিকটক আইকনগুলোর লিংক এখান থেকে সেট করুন
                        </p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {/* Facebook */}
                        <div>
                          <label className="block text-xs font-bold text-zinc-700 mb-1 flex items-center gap-1.5">
                            <Facebook className="w-3.5 h-3.5 text-[#1877F2]" />
                            <span>Facebook Page URL</span>
                          </label>
                          <input
                            type="url"
                            value={settingsForm.facebook || ''}
                            onChange={(e) => setSettingsForm({ ...settingsForm, facebook: e.target.value })}
                            placeholder="https://facebook.com/yourpage"
                            className="w-full bg-white text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                          />
                        </div>

                        {/* Instagram */}
                        <div>
                          <label className="block text-xs font-bold text-zinc-700 mb-1 flex items-center gap-1.5">
                            <Instagram className="w-3.5 h-3.5 text-[#E4405F]" />
                            <span>Instagram Profile URL</span>
                          </label>
                          <input
                            type="url"
                            value={settingsForm.instagram || ''}
                            onChange={(e) => setSettingsForm({ ...settingsForm, instagram: e.target.value })}
                            placeholder="https://instagram.com/yourprofile"
                            className="w-full bg-white text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                          />
                        </div>

                        {/* YouTube */}
                        <div>
                          <label className="block text-xs font-bold text-zinc-700 mb-1 flex items-center gap-1.5">
                            <Youtube className="w-3.5 h-3.5 text-[#FF0000]" />
                            <span>YouTube Channel URL</span>
                          </label>
                          <input
                            type="url"
                            value={settingsForm.youtube || ''}
                            onChange={(e) => setSettingsForm({ ...settingsForm, youtube: e.target.value })}
                            placeholder="https://youtube.com/@yourchannel"
                            className="w-full bg-white text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                          />
                        </div>

                        {/* TikTok */}
                        <div>
                          <label className="block text-xs font-bold text-zinc-700 mb-1 flex items-center gap-1.5">
                            <Music2 className="w-3.5 h-3.5 text-zinc-800" />
                            <span>TikTok Profile URL</span>
                          </label>
                          <input
                            type="url"
                            value={settingsForm.tiktok || ''}
                            onChange={(e) => setSettingsForm({ ...settingsForm, tiktok: e.target.value })}
                            placeholder="https://tiktok.com/@yourprofile"
                            className="w-full bg-white text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-zinc-700 mb-1">
                        Store Tagline
                      </label>
                      <input
                        type="text"
                        value={settingsForm.store_tagline || ''}
                        onChange={(e) => setSettingsForm({ ...settingsForm, store_tagline: e.target.value })}
                        className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-zinc-700 mb-1">
                        Announcement Bar Text
                      </label>
                      <input
                        type="text"
                        value={settingsForm.promo_text || ''}
                        onChange={(e) => setSettingsForm({ ...settingsForm, promo_text: e.target.value })}
                        placeholder="Cash on Delivery Available Across Bangladesh"
                        className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                      />
                    </div>
                  </div>

                  {/* Delivery Tariffs */}
                  <div className="pt-4 border-t border-zinc-200 space-y-4">
                    <h3 className="text-xs font-black uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
                      <Truck className="w-4 h-4 text-emerald-600" />
                      Delivery Charges (Bangladesh Taka ৳)
                    </h3>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="p-3 bg-zinc-50 rounded-2xl border border-zinc-200">
                        <label className="block text-xs font-bold text-zinc-700 mb-1">
                          Inside Dhaka City (৳)
                        </label>
                        <input
                          type="number"
                          value={settingsForm.delivery_inside_dhaka || 70}
                          onChange={(e) => setSettingsForm({ ...settingsForm, delivery_inside_dhaka: e.target.value })}
                          className="w-full bg-white text-zinc-900 text-sm p-2.5 rounded-xl border border-zinc-300 font-black"
                        />
                        <span className="text-[10px] text-zinc-400 block mt-1">Default: 70 BDT</span>
                      </div>

                      <div className="p-3 bg-zinc-50 rounded-2xl border border-zinc-200">
                        <label className="block text-xs font-bold text-zinc-700 mb-1">
                          Dhaka Sub-Area (৳)
                        </label>
                        <input
                          type="number"
                          value={settingsForm.delivery_sub_dhaka || 100}
                          onChange={(e) => setSettingsForm({ ...settingsForm, delivery_sub_dhaka: e.target.value })}
                          className="w-full bg-white text-zinc-900 text-sm p-2.5 rounded-xl border border-zinc-300 font-black"
                        />
                        <span className="text-[10px] text-zinc-400 block mt-1">Gazipur, Savar, Keraniganj, Demra</span>
                      </div>

                      <div className="p-3 bg-zinc-50 rounded-2xl border border-zinc-200">
                        <label className="block text-xs font-bold text-zinc-700 mb-1">
                          Outside Dhaka (৳)
                        </label>
                        <input
                          type="number"
                          value={settingsForm.delivery_outside_dhaka || 130}
                          onChange={(e) => setSettingsForm({ ...settingsForm, delivery_outside_dhaka: e.target.value })}
                          className="w-full bg-white text-zinc-900 text-sm p-2.5 rounded-xl border border-zinc-300 font-black"
                        />
                        <span className="text-[10px] text-zinc-400 block mt-1">Narayanganj & 63 districts (130 BDT)</span>
                      </div>
                    </div>
                  </div>

                  {/* Footer Copyright Text */}
                  <div className="pt-4 border-t border-zinc-200">
                    <label className="block text-xs font-bold text-zinc-700 mb-1">
                      Footer Copyright Text
                    </label>
                    <input
                      type="text"
                      value={settingsForm.footer_text || ''}
                      onChange={(e) => setSettingsForm({ ...settingsForm, footer_text: e.target.value })}
                      className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                    />
                  </div>

                  {/* Store Categories in General Settings with Edit Buttons */}
                  <div className="pt-6 border-t border-zinc-200 space-y-3.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <h3 className="text-sm font-black text-zinc-900 flex items-center gap-2">
                          <FolderTree className="w-4 h-4 text-emerald-600" />
                          <span>Store Categories & Status ({dbCategories.length})</span>
                        </h3>
                        <p className="text-xs text-zinc-500">
                          Edit category names or toggle active/hidden status. Updates persist directly to Firestore.
                        </p>
                      </div>

                      <div className="flex items-center gap-2 self-start sm:self-auto">
                        <button
                          type="button"
                          onClick={() => {
                            setSettingsSubTab('categories');
                            loadCategories();
                            loadProducts(password);
                          }}
                          className="text-xs text-emerald-600 font-bold hover:underline cursor-pointer"
                        >
                          Manage in Categories Tab
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setCategoryToEdit({
                              id: `cat-${Date.now()}`,
                              name: '',
                              slug: '',
                              active: 1,
                              display_order: dbCategories.length + 1,
                            });
                            setIsCategoryEditModalOpen(true);
                          }}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Add Category</span>
                        </button>
                      </div>
                    </div>

                    {dbCategories.length === 0 ? (
                      <div className="p-6 bg-zinc-50 rounded-2xl border border-dashed border-zinc-200 text-center">
                        <p className="text-xs text-zinc-500 font-medium">No categories found in store.</p>
                      </div>
                    ) : (
                      <div className="bg-zinc-50 rounded-2xl border border-zinc-200 divide-y divide-zinc-200 overflow-hidden">
                        {dbCategories.map((cat) => {
                          const catProdCount = products.filter((p) => isProductInCategory(p, cat)).length;
                          const isActive = cat.active !== 0;

                          return (
                            <div
                              key={cat.id || cat.slug}
                              className="p-3 sm:p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-zinc-100/70 transition-colors"
                            >
                              <div className="flex items-center gap-3 min-w-0">
                                <div className="w-8 h-8 rounded-xl bg-white border border-zinc-200 text-emerald-600 flex items-center justify-center shrink-0 shadow-xs">
                                  <FolderTree className="w-4 h-4" />
                                </div>
                                <div className="min-w-0">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <h4 className="text-xs sm:text-sm font-black text-zinc-900 truncate">
                                      {cat.name}
                                    </h4>
                                    <span
                                      className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                                        isActive
                                          ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                                          : 'bg-zinc-200 text-zinc-600 border-zinc-300'
                                      }`}
                                    >
                                      {isActive ? 'Active' : 'Hidden'}
                                    </span>
                                  </div>
                                  <div className="text-[11px] text-zinc-500 font-mono mt-0.5">
                                    /{cat.slug || generateSlug(cat.name)} • {catProdCount} {catProdCount === 1 ? 'product' : 'products'}
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                                <button
                                  type="button"
                                  onClick={() => handleToggleCategoryStatus(cat)}
                                  title={isActive ? 'Click to hide category from website' : 'Click to show category on website'}
                                  className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                                    isActive
                                      ? 'bg-white hover:bg-zinc-100 text-zinc-700 border-zinc-200'
                                      : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-300'
                                  }`}
                                >
                                  {isActive ? 'Hide' : 'Activate'}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleOpenCategoryEditModal(cat)}
                                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-emerald-600 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                  <span>Edit</span>
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </>
              ) : (
                /* Marketing Sub-tab */
                <div className="space-y-6">
                  {/* Meta / Facebook Pixel */}
                  <div className="p-4 rounded-2xl bg-blue-50/50 border border-blue-100 space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-sm">
                        f
                      </div>
                      <div>
                        <h4 className="font-extrabold text-sm text-zinc-900">
                          Meta / Facebook Pixel ID
                        </h4>
                        <p className="text-[11px] text-zinc-500">
                          Tracks PageView, ViewContent, AddToCart, InitiateCheckout & Purchase (with ৳ total)
                        </p>
                      </div>
                    </div>

                    <input
                      type="text"
                      placeholder="e.g. 123456789012345"
                      value={settingsForm.meta_pixel_id || ''}
                      onChange={(e) => setSettingsForm({ ...settingsForm, meta_pixel_id: e.target.value })}
                      className="w-full bg-white text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-blue-200 focus:outline-none focus:border-blue-600 font-mono"
                    />
                  </div>

                  {/* Google Tag / GA4 */}
                  <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-100 space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
                        G
                      </div>
                      <div>
                        <h4 className="font-extrabold text-sm text-zinc-900">
                          Google Tag / Google Ads / GA4 Measurement ID
                        </h4>
                        <p className="text-[11px] text-zinc-500">
                          Integrates Google Ads conversions & Google Analytics 4 (e.g. G-XXXXX or AW-XXXXX)
                        </p>
                      </div>
                    </div>

                    <input
                      type="text"
                      placeholder="e.g. G-XXXXXXXXXX or AW-XXXXXXXXXX"
                      value={settingsForm.google_tag_id || ''}
                      onChange={(e) => setSettingsForm({ ...settingsForm, google_tag_id: e.target.value })}
                      className="w-full bg-white text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-emerald-200 focus:outline-none focus:border-emerald-600 font-mono"
                    />
                  </div>

                  {/* TikTok Pixel */}
                  <div className="p-4 rounded-2xl bg-zinc-50 border border-zinc-200 space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-zinc-950 text-white flex items-center justify-center font-bold text-xs">
                        TT
                      </div>
                      <div>
                        <h4 className="font-extrabold text-sm text-zinc-900">
                          TikTok Pixel ID
                        </h4>
                        <p className="text-[11px] text-zinc-500">
                          Track TikTok ads traffic & conversions
                        </p>
                      </div>
                    </div>

                    <input
                      type="text"
                      placeholder="e.g. CXXXXXXXXXXXXXXX"
                      value={settingsForm.tiktok_pixel_id || ''}
                      onChange={(e) => setSettingsForm({ ...settingsForm, tiktok_pixel_id: e.target.value })}
                      className="w-full bg-white text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900 font-mono"
                    />
                  </div>

                  {/* Global Homepage SEO */}
                  <div className="space-y-4 pt-2">
                    <h3 className="text-xs font-black uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
                      <Globe className="w-4 h-4 text-blue-600" />
                      Global Homepage SEO
                    </h3>

                    <div>
                      <label className="block text-xs font-bold text-zinc-700 mb-1">
                        Homepage Meta Title
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Maxora BD | Premium Smart Gadgets & Lifestyle Store"
                        value={settingsForm.site_meta_title || ''}
                        onChange={(e) => setSettingsForm({ ...settingsForm, site_meta_title: e.target.value })}
                        className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-zinc-700 mb-1">
                        Homepage Meta Description
                      </label>
                      <textarea
                        rows={2}
                        placeholder="Shop genuine smartwatches, earbuds and gadgets with Cash on Delivery..."
                        value={settingsForm.site_meta_description || ''}
                        onChange={(e) => setSettingsForm({ ...settingsForm, site_meta_description: e.target.value })}
                        className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900 resize-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div className="pt-3">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3.5 rounded-2xl bg-zinc-950 hover:bg-zinc-800 text-white font-extrabold text-sm transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
                >
                  <Save className="w-4 h-4 text-emerald-400" />
                  <span>Save Store Settings</span>
                </button>
              </div>
            </form>
            )}
          </div>
        )}
      </main>

      {/* ====================================================
          PRODUCT MODAL (ADD / EDIT)
      ==================================================== */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-zinc-950/70 backdrop-blur-sm">
          <div className="relative bg-white w-full max-w-2xl rounded-3xl overflow-hidden shadow-2xl border border-zinc-200 max-h-[92vh] flex flex-col">
            <div className="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50">
              <div className="flex items-center gap-3">
                <h3 className="font-extrabold text-base text-zinc-900">
                  {editingProduct?.id ? 'Edit Product' : 'Add New Product'}
                </h3>
                <div className="flex items-center gap-1 bg-zinc-200/80 p-0.5 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setProductModalTab('general')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      productModalTab === 'general'
                        ? 'bg-white text-zinc-950 shadow-xs'
                        : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    Details
                  </button>
                  <button
                    type="button"
                    onClick={() => setProductModalTab('variants')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      productModalTab === 'variants'
                        ? 'bg-white text-zinc-950 shadow-xs'
                        : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    <Palette className="w-3.5 h-3.5" />
                    <span>Colors ({editingProduct?.colors?.length || 0})</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setProductModalTab('seo')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      productModalTab === 'seo'
                        ? 'bg-white text-zinc-950 shadow-xs'
                        : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    <span>Google SEO</span>
                    {editingProduct?.meta_keywords && (
                      <span className="w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-emerald-100"></span>
                    )}
                  </button>
                </div>
              </div>
              <button
                onClick={() => setIsProductModalOpen(false)}
                className="w-8 h-8 rounded-full border border-zinc-200 flex items-center justify-center text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="p-6 overflow-y-auto space-y-4">
              {productModalTab === 'general' && (
                <>
                  <div>
                    <label className="block text-xs font-bold text-zinc-700 mb-1">
                      Product Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Ultra Smart Watch Series 9"
                      value={editingProduct?.name || ''}
                      onChange={(e) => {
                        const newName = e.target.value;
                        const prevNameSlug = generateSlug(editingProduct?.name || '');
                        const shouldUpdateSlug = !editingProduct?.slug || editingProduct.slug === prevNameSlug;
                        setEditingProduct({
                          ...editingProduct,
                          name: newName,
                          slug: shouldUpdateSlug ? generateSlug(newName) : editingProduct.slug,
                        });
                      }}
                      className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                    />
                  </div>

                  {/* Brand Select Dropdown */}
                  <div className="bg-amber-500/5 p-3.5 rounded-2xl border border-amber-500/20">
                    <BrandSelectDropdown
                      value={editingProduct?.brand || 'Other'}
                      required
                      brandsList={dbBrands}
                      onChange={(brandName, brandId, brandSlug) => {
                        setEditingProduct((prev) =>
                          prev
                            ? {
                                ...prev,
                                brand: brandName,
                                brand_id: brandId,
                                brand_slug: brandSlug,
                              }
                            : prev
                        );
                      }}
                    />
                  </div>

                  {/* Category, Sub Category, Child Category & Product Type */}
                  <div className="bg-zinc-50/80 p-4 rounded-2xl border border-zinc-200/90 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-extrabold text-zinc-800 flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Category & Taxonomy (ক্যাটেগরি ও ধরণ)</span>
                      </label>
                      <span className="text-[11px] text-zinc-400 font-medium">Categorization Hierarchy</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {/* 1. Category */}
                      <div>
                        <label className="block text-xs font-bold text-zinc-700 mb-1">
                          Category (ক্যাটেগরি) *
                        </label>
                        <select
                          required
                          value={
                            dbCategories.some(
                              (c) => c.name.toLowerCase() === (editingProduct?.category || '').toLowerCase()
                            )
                              ? dbCategories.find(
                                  (c) => c.name.toLowerCase() === (editingProduct?.category || '').toLowerCase()
                                )?.name
                              : editingProduct?.category || ''
                          }
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '__custom__') {
                              const customName = prompt('Enter custom category name:');
                              if (customName && customName.trim()) {
                                setEditingProduct({
                                  ...editingProduct,
                                  category: customName.trim(),
                                  category_id: '',
                                  category_slug: customName.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-'),
                                });
                              }
                              return;
                            }
                            const matchedCat = dbCategories.find(
                              (c) => c.name === val || c.id === val || c.slug === val
                            );
                            setEditingProduct({
                              ...editingProduct,
                              category: matchedCat ? matchedCat.name : val,
                              category_id: matchedCat?.id || '',
                              category_slug: matchedCat?.slug || '',
                            });
                          }}
                          className="w-full bg-white text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900 font-medium"
                        >
                          <option value="">-- Select Category --</option>
                          {dbCategories.map((c) => (
                            <option key={c.id} value={c.name}>
                              {c.name}
                            </option>
                          ))}
                          {dbCategories.length === 0 && (
                            <>
                              <option value="Smart Gadgets">Smart Gadgets</option>
                              <option value="Audio">Audio</option>
                              <option value="Computer & Gaming">Computer & Gaming</option>
                              <option value="Mobile Accessories">Mobile Accessories</option>
                              <option value="Lifestyle & Bags">Lifestyle & Bags</option>
                              <option value="Home & Living">Home & Living</option>
                              <option value="Fashion & Apparel">Fashion & Apparel</option>
                              <option value="Watches & Wearables">Watches & Wearables</option>
                            </>
                          )}
                          <option value="__custom__">+ Add Custom Category...</option>
                        </select>
                      </div>

                      {/* 2. Sub Category */}
                      <div>
                        <label className="block text-xs font-bold text-zinc-700 mb-1">
                          Sub Category (সাব ক্যাটেগরি)
                        </label>
                        <select
                          value={
                            dbSubCategories.some(
                              (s) => s.name.toLowerCase() === (editingProduct?.sub_category || '').toLowerCase()
                            )
                              ? dbSubCategories.find(
                                  (s) => s.name.toLowerCase() === (editingProduct?.sub_category || '').toLowerCase()
                                )?.name
                              : editingProduct?.sub_category || ''
                          }
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '__custom__') {
                              const customSub = prompt('Enter custom subcategory name:');
                              if (customSub && customSub.trim()) {
                                setEditingProduct({
                                  ...editingProduct,
                                  sub_category: customSub.trim(),
                                  subcategory_id: '',
                                  subcategory_slug: customSub.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-'),
                                });
                              }
                              return;
                            }
                            const matchedSub = dbSubCategories.find(
                              (s) => s.name === val || s.id === val || s.slug === val
                            );
                            setEditingProduct({
                              ...editingProduct,
                              sub_category: matchedSub ? matchedSub.name : val,
                              subcategory_id: matchedSub?.id || '',
                              subcategory_slug: matchedSub?.slug || '',
                            });
                          }}
                          className="w-full bg-white text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900 font-medium"
                        >
                          <option value="">-- Select Sub Category (Optional) --</option>
                          {dbSubCategories
                            .filter((s) => {
                              if (!editingProduct?.category) return true;
                              const currentCat = editingProduct.category.toLowerCase().trim();
                              const parentCat = dbCategories.find((c) => c.id === s.category_id);
                              return (
                                s.category_id === editingProduct.category_id ||
                                s.category_slug === editingProduct.category_slug ||
                                (parentCat && parentCat.name.toLowerCase().trim() === currentCat)
                              );
                            })
                            .map((s) => (
                              <option key={s.id} value={s.name}>
                                {s.name}
                              </option>
                            ))}
                          <option value="__custom__">+ Add Custom Subcategory...</option>
                        </select>
                      </div>

                      {/* 3. Child Category */}
                      <div>
                        <label className="block text-xs font-bold text-zinc-700 mb-1">
                          Child Category (চাইল্ড ক্যাটেগরি)
                        </label>
                        <input
                          list="admin-childcategory-list-root"
                          type="text"
                          placeholder="e.g. AMOLED Display, ANC Earbuds"
                          value={editingProduct?.child_category || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, child_category: e.target.value })}
                          className="w-full bg-white text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900 font-medium"
                        />
                        <datalist id="admin-childcategory-list-root">
                          <option value="AMOLED Calling" />
                          <option value="Waterproof IP68" />
                          <option value="Active Noise Cancelling (ANC)" />
                          <option value="Deep Bass Gaming" />
                          <option value="65W Fast GaN" />
                          <option value="100W PD Type-C" />
                          <option value="RGB Hot-swappable" />
                        </datalist>
                      </div>

                      {/* 4. Product Type */}
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="block text-xs font-bold text-zinc-700">
                            Product Type (প্রোডাক্ট টাইপ)
                          </label>
                          <button
                            type="button"
                            onClick={() => setShowAddTypeInput(!showAddTypeInput)}
                            className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                            <span>{showAddTypeInput ? 'Cancel' : '+ Add Custom Type (নতুন টাইপ)'}</span>
                          </button>
                        </div>

                        {showAddTypeInput ? (
                          <div className="flex items-center gap-2 p-2 bg-emerald-50 rounded-xl border border-emerald-200">
                            <input
                              type="text"
                              placeholder="Type custom product type name..."
                              value={newProductTypeInput}
                              onChange={(e) => setNewProductTypeInput(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  handleAddNewProductType();
                                }
                              }}
                              className="flex-1 bg-white text-zinc-900 text-xs p-2 rounded-lg border border-emerald-300 focus:outline-none focus:border-emerald-600 font-medium"
                              autoFocus
                            />
                            <button
                              type="button"
                              onClick={() => handleAddNewProductType()}
                              className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                            >
                              Add
                            </button>
                          </div>
                        ) : (
                          <div className="flex gap-2">
                            <div className="relative flex-1">
                              <input
                                list="admin-product-type-datalist"
                                type="text"
                                placeholder="Select or type any custom product type..."
                                value={editingProduct?.product_type || 'Standard Product'}
                                onChange={(e) => setEditingProduct({ ...editingProduct, product_type: e.target.value })}
                                className="w-full bg-white text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900 font-medium"
                              />
                              <datalist id="admin-product-type-datalist">
                                {availableProductTypes.map((t) => (
                                  <option key={t} value={t} />
                                ))}
                              </datalist>
                            </div>
                            <button
                              type="button"
                              onClick={() => setIsManageTypesModalOpen(true)}
                              className="px-3 py-3 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 rounded-xl border border-zinc-300 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1 shrink-0"
                              title="Manage all custom product types"
                            >
                              <SettingsIcon className="w-3.5 h-3.5" />
                              <span className="hidden sm:inline">Manage</span>
                            </button>
                          </div>
                        )}
                        <p className="text-[11px] text-zinc-500 mt-1">
                          You can choose from the list or freely type any custom product type.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-zinc-700 mb-1">
                        Buying Price (৳)
                      </label>
                      <input
                        type="number"
                        placeholder="Cost price"
                        value={editingProduct?.buying_price || ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, buying_price: Number(e.target.value) })}
                        className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-zinc-700 mb-1">
                        Selling Price (৳) *
                      </label>
                      <input
                        type="number"
                        required
                        placeholder="Regular price"
                        value={editingProduct?.selling_price || ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, selling_price: Number(e.target.value) })}
                        className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-zinc-700 mb-1">
                        Discount (৳)
                      </label>
                      <input
                        type="number"
                        placeholder="Discount"
                        value={editingProduct?.discount || ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, discount: Number(e.target.value) })}
                        className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 text-rose-600 font-bold"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-zinc-700 mb-1">
                        SKU / Code
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. MX-WTCH-01"
                        value={editingProduct?.sku || ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, sku: e.target.value })}
                        className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-zinc-700 mb-1">
                        Stock Quantity (Units)
                      </label>
                      <input
                        type="number"
                        value={editingProduct?.stock || 0}
                        onChange={(e) => setEditingProduct({ ...editingProduct, stock: Number(e.target.value) })}
                        className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-zinc-700 mb-1">
                        Badge (e.g. HOT, SALE, NEW)
                      </label>
                      <input
                        type="text"
                        placeholder="HOT"
                        value={editingProduct?.badge || ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, badge: e.target.value })}
                        className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 uppercase"
                      />
                    </div>
                  </div>

                  {/* Product Direct Link (প্রোডাক্টের সরাসরি লিংক) */}
                  <div className="bg-zinc-50/90 p-4 rounded-2xl border border-zinc-200/90 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <label className="block text-xs font-bold text-zinc-800 flex items-center gap-1.5">
                        <Link2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Product Link / Direct URL (প্রোডাক্টের লিংক)</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => {
                          const directId = editingProduct?.id || (editingProduct?.name ? editingProduct.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') : 'product');
                          const autoLink = `${window.location.origin}/?product=${directId}`;
                          setEditingProduct({ ...editingProduct, product_link: autoLink });
                          showToast('Storefront direct product link generated!', 'success');
                        }}
                        className="text-[11px] font-bold text-emerald-600 hover:text-emerald-700 hover:underline inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Sparkles className="w-3 h-3" /> Auto Generate Storefront Link
                      </button>
                    </div>

                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <input
                          type="text"
                          placeholder="e.g. https://yourdomain.com/?product=watch-01 or custom landing link"
                          value={editingProduct?.product_link || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, product_link: e.target.value })}
                          className="w-full bg-white text-zinc-900 text-xs sm:text-sm pl-9 pr-3 py-2.5 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                        />
                        <Link2 className="w-4 h-4 text-zinc-400 absolute left-3 top-3" />
                      </div>
                      {editingProduct?.product_link && (
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(editingProduct.product_link || '');
                            showToast('Product link copied to clipboard!', 'success');
                          }}
                          className="px-3.5 py-2.5 bg-zinc-200 hover:bg-zinc-300 text-zinc-800 rounded-xl text-xs font-bold flex items-center gap-1.5 shrink-0 cursor-pointer"
                          title="Copy Link"
                        >
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </button>
                      )}
                    </div>
                    <p className="text-[11px] text-zinc-500">
                      Facebook বা WhatsApp ক্যাম্পেইনের জন্য সরাসরি এই প্রোডাক্ট পেজে কাস্টমার আনার লিংক।
                    </p>
                  </div>

                  {/* Product Image Section: Direct Device Upload + Live Preview + URL Toggle */}
                  <div className="bg-zinc-50/90 p-4 rounded-2xl border border-zinc-200/90 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="block text-xs font-bold text-zinc-800 flex items-center gap-1.5">
                        <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Product Image (প্রোডাক্টের সরাসরি ছবি) *</span>
                      </label>
                      <div className="flex items-center bg-zinc-200/90 p-0.5 rounded-lg text-[11px]">
                        <button
                          type="button"
                          onClick={() => setImageInputMode('upload')}
                          className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                            imageInputMode === 'upload' ? 'bg-white text-zinc-950 shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
                          }`}
                        >
                          Upload from Device
                        </button>
                        <button
                          type="button"
                          onClick={() => setImageInputMode('url')}
                          className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                            imageInputMode === 'url' ? 'bg-white text-zinc-950 shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
                          }`}
                        >
                          Web URL
                        </button>
                      </div>
                    </div>

                    {/* Current Main Image Preview Card */}
                    {editingProduct?.image_url && (
                      <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-zinc-200 shadow-xs">
                        <div className="w-16 h-16 rounded-xl overflow-hidden bg-zinc-100 border border-zinc-200 shrink-0 shadow-inner">
                          <img
                            src={editingProduct.image_url}
                            alt="Preview"
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80";
                            }}
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
                            <p className="text-xs font-bold text-zinc-900 truncate">Main Photo Set</p>
                          </div>
                          <p className="text-[11px] text-zinc-500 truncate mt-0.5">
                            {editingProduct.image_url.startsWith('data:') ? 'Uploaded directly from device' : editingProduct.image_url}
                          </p>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <label className="px-3 py-1.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 rounded-lg text-xs font-bold cursor-pointer transition-colors inline-flex items-center gap-1">
                            <Upload className="w-3.5 h-3.5" />
                            <span>Change</span>
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) handleMainImageFileChange(file);
                              }}
                            />
                          </label>
                          <button
                            type="button"
                            onClick={() => setEditingProduct({ ...editingProduct, image_url: '' })}
                            className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg cursor-pointer transition-colors"
                            title="Remove Photo"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Upload Box: Drag and Drop or Direct Device File Picker */}
                    {imageInputMode === 'upload' && !editingProduct?.image_url && (
                      <label
                        onDragOver={(e) => { e.preventDefault(); setIsDraggingImage(true); }}
                        onDragLeave={() => setIsDraggingImage(false)}
                        onDrop={(e) => {
                          e.preventDefault();
                          setIsDraggingImage(false);
                          const file = e.dataTransfer.files?.[0];
                          if (file) handleMainImageFileChange(file);
                        }}
                        className={`border-2 border-dashed rounded-2xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${
                          isDraggingImage ? 'border-emerald-500 bg-emerald-50/60' : 'border-zinc-300 hover:border-zinc-900 bg-white'
                        }`}
                      >
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleMainImageFileChange(file);
                          }}
                        />
                        <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-2 shadow-xs">
                          {isUploadingImage ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Camera className="w-6 h-6" />}
                        </div>
                        <p className="text-xs font-bold text-zinc-900">
                          {isUploadingImage ? 'Processing & Optimizing Image...' : 'Click to Choose Photo from Device / Gallery'}
                        </p>
                        <p className="text-[11px] text-zinc-500 mt-1">
                          সরাসরি মোবাইল বা কম্পিউটার থেকে ছবি সিলেক্ট বা ড্র্যাগ করুন (JPG, PNG, WEBP)
                        </p>
                      </label>
                    )}

                    {/* URL Input Mode */}
                    {imageInputMode === 'url' && (
                      <div className="space-y-1">
                        <input
                          type="url"
                          placeholder="https://images.unsplash.com/photo-..."
                          value={editingProduct?.image_url || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, image_url: e.target.value })}
                          className="w-full bg-white text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                        />
                        <p className="text-[10px] text-zinc-500">অনলাইন কোনো ছবি থাকলে তার লিংক এখানে পেস্ট করতে পারেন।</p>
                      </div>
                    )}

                    {/* Additional Gallery Photos */}
                    <div className="pt-3 border-t border-zinc-200/80">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-bold text-zinc-700">More Gallery Photos (অতিরিক্ত ছবি)</span>
                        <label className="text-[11px] font-bold text-emerald-600 hover:text-emerald-700 hover:underline inline-flex items-center gap-1 cursor-pointer">
                          <Plus className="w-3.5 h-3.5" /> Upload More
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) handleGalleryImageUpload(file);
                            }}
                          />
                        </label>
                      </div>

                      {Array.isArray(editingProduct?.images) && editingProduct.images.length > 0 && (
                        <div className="flex flex-wrap gap-2.5">
                          {editingProduct.images.map((img, idx) => (
                            <div key={idx} className="relative w-14 h-14 rounded-xl overflow-hidden border border-zinc-300 bg-white group shadow-xs">
                              <img src={img} alt={`Gallery ${idx}`} className="w-full h-full object-cover" />
                              <button
                                type="button"
                                onClick={() => handleRemoveGalleryImage(idx)}
                                className="absolute top-1 right-1 w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center text-xs shadow-md hover:scale-110 transition-transform cursor-pointer"
                                title="Delete photo"
                              >
                                ✕
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-zinc-700 mb-1">
                      Product Description
                    </label>
                    <textarea
                      rows={3}
                      value={editingProduct?.description || ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                      className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 resize-none"
                    />
                  </div>

                  {/* Quick Shortcut to Color Variants */}
                  <div className="p-3.5 bg-purple-50/70 border border-purple-200/80 rounded-2xl flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-xl bg-purple-700 text-white flex items-center justify-center shrink-0 font-bold">
                        <Palette className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-extrabold text-purple-950">Color Variants (কালার ভ্যারিয়েন্ট)</p>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          {editingProduct?.colors && editingProduct.colors.length > 0 ? (
                            <>
                              <div className="flex items-center -space-x-1">
                                {editingProduct.colors.map((c, i) => (
                                  <span
                                    key={i}
                                    title={`${c.name} (${c.stock} in stock)`}
                                    className="w-3.5 h-3.5 rounded-full border-2 border-white shadow-2xs inline-block"
                                    style={{ backgroundColor: c.code || '#71717a' }}
                                  />
                                ))}
                              </div>
                              <span className="text-[11px] font-bold text-purple-700">
                                {editingProduct.colors.length} টি কালার যুক্ত আছে ({editingProduct.colors.reduce((sum, c) => sum + (c.stock || 0), 0)} মোট স্টক)
                              </span>
                            </>
                          ) : (
                            <span className="text-[11px] text-purple-700 truncate">
                              কালার ভ্যারিয়েন্ট যুক্ত করুন যাতে কাস্টমার পছন্দের কালার নির্বাচন করতে পারেন
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setProductModalTab('variants')}
                      className="px-3 py-1.5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer shrink-0 flex items-center gap-1"
                    >
                      <Palette className="w-3.5 h-3.5" />
                      <span>{editingProduct?.colors?.length ? 'কালার ম্যানেজ করুন' : '+ কালার যোগ করুন'}</span>
                    </button>
                  </div>

                  {/* Quick Shortcut to Google SEO */}
                  <div className="p-3.5 bg-blue-50/70 border border-blue-200/80 rounded-2xl flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 font-bold">
                        <Globe className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-extrabold text-blue-950">Google SEO & Search Keywords (গুগল এসইও কি-ওয়ার্ড)</p>
                        <p className="text-[11px] text-blue-700 truncate">
                          {editingProduct?.meta_keywords
                            ? `${editingProduct.meta_keywords.split(',').filter(k => k.trim()).length} টি কি-ওয়ার্ড কনফিগার করা আছে`
                            : 'গুগল সার্চ ও শপিংয়ে দ্রুত খুঁজে পেতে কি-ওয়ার্ড যুক্ত করুন'}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setProductModalTab('seo')}
                      className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer shrink-0 flex items-center gap-1"
                    >
                      <span>এসইও কি-ওয়ার্ড</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="flex items-center gap-6 pt-2">
                    <label className="flex items-center gap-2 text-xs font-bold text-zinc-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editingProduct?.active !== 0}
                        onChange={(e) => setEditingProduct({ ...editingProduct, active: e.target.checked ? 1 : 0 })}
                        className="w-4 h-4 rounded text-emerald-600"
                      />
                      <span>Active & Available for Shopping</span>
                    </label>

                    <label className="flex items-center gap-2 text-xs font-bold text-zinc-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(editingProduct?.featured)}
                        onChange={(e) => setEditingProduct({ ...editingProduct, featured: e.target.checked ? 1 : 0 })}
                        className="w-4 h-4 rounded text-emerald-600"
                      />
                      <span>Feature on Storefront Hero</span>
                    </label>
                  </div>

                  {/* Homepage Sections & Promotional Flags (Requirement 17) */}
                  <div className="mt-3 p-4 bg-zinc-50 border border-zinc-200/90 rounded-2xl space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-black text-zinc-900 uppercase tracking-wider flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-emerald-600" />
                        <span>Homepage Sections & Promotions (হোমপেজ সেকশন নিয়ন্ত্রণ)</span>
                      </h4>
                      <span className="text-[10px] text-zinc-500 font-medium">Automatic Storefront Sync</span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
                      {/* Hot Deal */}
                      <label className={`p-3 rounded-xl border flex flex-col gap-1 cursor-pointer transition-all ${
                        editingProduct?.is_hot_deal
                          ? 'bg-rose-50 border-rose-300 text-rose-950 shadow-2xs'
                          : 'bg-white border-zinc-200 text-zinc-700 hover:bg-zinc-100'
                      }`}>
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-extrabold flex items-center gap-1">
                            <span>🔥 Hot Deal</span>
                          </span>
                          <input
                            type="checkbox"
                            checked={Boolean(editingProduct?.is_hot_deal)}
                            onChange={(e) => setEditingProduct({ ...editingProduct, is_hot_deal: e.target.checked })}
                            className="w-4 h-4 rounded text-rose-600 cursor-pointer"
                          />
                        </div>
                        <span className="text-[10px] text-zinc-500">Show in Hot Deals section</span>
                      </label>

                      {/* Flash Sale */}
                      <label className={`p-3 rounded-xl border flex flex-col gap-1 cursor-pointer transition-all ${
                        editingProduct?.is_flash_sale
                          ? 'bg-amber-50 border-amber-300 text-amber-950 shadow-2xs'
                          : 'bg-white border-zinc-200 text-zinc-700 hover:bg-zinc-100'
                      }`}>
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-extrabold flex items-center gap-1">
                            <span>⚡ Flash Sale</span>
                          </span>
                          <input
                            type="checkbox"
                            checked={Boolean(editingProduct?.is_flash_sale)}
                            onChange={(e) => setEditingProduct({ ...editingProduct, is_flash_sale: e.target.checked })}
                            className="w-4 h-4 rounded text-amber-600 cursor-pointer"
                          />
                        </div>
                        <span className="text-[10px] text-zinc-500">Show in Flash Sale bar</span>
                      </label>

                      {/* New Arrival */}
                      <label className={`p-3 rounded-xl border flex flex-col gap-1 cursor-pointer transition-all ${
                        editingProduct?.is_new_arrival
                          ? 'bg-blue-50 border-blue-300 text-blue-950 shadow-2xs'
                          : 'bg-white border-zinc-200 text-zinc-700 hover:bg-zinc-100'
                      }`}>
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-extrabold flex items-center gap-1">
                            <span>🆕 New Arrival</span>
                          </span>
                          <input
                            type="checkbox"
                            checked={Boolean(editingProduct?.is_new_arrival)}
                            onChange={(e) => setEditingProduct({ ...editingProduct, is_new_arrival: e.target.checked })}
                            className="w-4 h-4 rounded text-blue-600 cursor-pointer"
                          />
                        </div>
                        <span className="text-[10px] text-zinc-500">Show in New Arrivals</span>
                      </label>

                      {/* Best Seller */}
                      <label className={`p-3 rounded-xl border flex flex-col gap-1 cursor-pointer transition-all ${
                        editingProduct?.is_best_seller
                          ? 'bg-emerald-50 border-emerald-300 text-emerald-950 shadow-2xs'
                          : 'bg-white border-zinc-200 text-zinc-700 hover:bg-zinc-100'
                      }`}>
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-extrabold flex items-center gap-1">
                            <span>⭐ Best Seller</span>
                          </span>
                          <input
                            type="checkbox"
                            checked={Boolean(editingProduct?.is_best_seller)}
                            onChange={(e) => setEditingProduct({ ...editingProduct, is_best_seller: e.target.checked })}
                            className="w-4 h-4 rounded text-emerald-600 cursor-pointer"
                          />
                        </div>
                        <span className="text-[10px] text-zinc-500">Show in Best Sellers</span>
                      </label>
                    </div>

                    {/* Flash Sale specific details when Flash Sale is ON */}
                    {editingProduct?.is_flash_sale && (
                      <div className="mt-3 p-3.5 bg-amber-500/10 border border-amber-300/80 rounded-xl space-y-2.5">
                        <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900">
                          <Clock className="w-3.5 h-3.5 text-amber-600" />
                          <span>Flash Sale Settings (ফ্ল্যাশ সেল স্পেশাল প্রাইস ও সময়সীমা)</span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                          <div>
                            <label className="block text-[11px] font-bold text-zinc-700 mb-1">
                              Flash Sale Price (৳):
                            </label>
                            <input
                              type="number"
                              min="0"
                              placeholder="e.g. 1150"
                              value={editingProduct?.flash_sale_price || ''}
                              onChange={(e) => setEditingProduct({
                                ...editingProduct,
                                flash_sale_price: e.target.value ? Number(e.target.value) : undefined
                              })}
                              className="w-full bg-white border border-amber-300 rounded-lg px-2.5 py-1.5 text-xs font-bold text-zinc-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                            />
                          </div>

                          <div>
                            <label className="block text-[11px] font-bold text-zinc-700 mb-1">
                              Start Date/Time:
                            </label>
                            <input
                              type="datetime-local"
                              value={editingProduct?.flash_sale_start ? String(editingProduct.flash_sale_start).substring(0, 16) : ''}
                              onChange={(e) => setEditingProduct({
                                ...editingProduct,
                                flash_sale_start: e.target.value
                              })}
                              className="w-full bg-white border border-amber-300 rounded-lg px-2.5 py-1.5 text-xs text-zinc-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                            />
                          </div>

                          <div>
                            <label className="block text-[11px] font-bold text-zinc-700 mb-1">
                              End Date/Time:
                            </label>
                            <input
                              type="datetime-local"
                              value={editingProduct?.flash_sale_end ? String(editingProduct.flash_sale_end).substring(0, 16) : ''}
                              onChange={(e) => setEditingProduct({
                                ...editingProduct,
                                flash_sale_end: e.target.value
                              })}
                              className="w-full bg-white border border-amber-300 rounded-lg px-2.5 py-1.5 text-xs text-zinc-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </>
              )}

              {/* TAB 2: COLOR VARIANTS MANAGEMENT */}
              {productModalTab === 'variants' && (
                <div className="space-y-5 animate-fade-in">
                  <div className="p-4 bg-purple-50/80 border border-purple-200 rounded-2xl flex items-start gap-3">
                    <div className="w-9 h-9 rounded-xl bg-purple-700 text-white flex items-center justify-center shrink-0 shadow-xs mt-0.5">
                      <Palette className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-extrabold text-purple-950">
                        Product Color Variants (কালার ভ্যারিয়েন্ট কনফিগারেশন)
                      </h4>
                      <p className="text-[11px] text-purple-700 leading-relaxed mt-0.5">
                        প্রোডাক্টের একাধিক কালার, প্রতি কালারের আলাদা স্টক ও নিজস্ব ছবি যুক্ত করুন। স্টোরফ্রন্টে কাস্টমার কালার অনুযায়ী ক্লিক করে লাইভ ছবি দেখতে ও অর্ডার করতে পারবেন।
                      </p>
                    </div>
                  </div>

                  {/* Quick Color Presets */}
                  <div className="bg-zinc-50/90 p-4 rounded-2xl border border-zinc-200/90 space-y-2.5">
                    <label className="block text-xs font-bold text-zinc-700">
                      Quick Color Presets (দ্রুত কালার সিলেক্ট করুন):
                    </label>
                    <div className="flex flex-wrap gap-1.5">
                      {[
                        { name: 'Midnight Black', code: '#09090b' },
                        { name: 'Pure White', code: '#ffffff' },
                        { name: 'Navy Blue', code: '#1e3a8a' },
                        { name: 'Crimson Red', code: '#dc2626' },
                        { name: 'Emerald Green', code: '#059669' },
                        { name: 'Titanium Gray', code: '#4b5563' },
                        { name: 'Rose Gold', code: '#e0a899' },
                        { name: 'Royal Blue', code: '#2563eb' },
                        { name: 'Gold', code: '#d97706' },
                        { name: 'Silver', code: '#9ca3af' },
                        { name: 'Deep Purple', code: '#7c3aed' },
                        { name: 'Sunset Orange', code: '#ea580c' },
                      ].map((preset, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setNewColorName(preset.name);
                            setNewColorCode(preset.code);
                          }}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white hover:bg-zinc-100 border border-zinc-200 text-[11px] font-semibold text-zinc-800 transition-colors shadow-2xs cursor-pointer"
                        >
                          <span
                            className="w-3 h-3 rounded-full border border-zinc-300 inline-block shadow-xs"
                            style={{ backgroundColor: preset.code }}
                          />
                          <span>{preset.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Add New Color Variant Form */}
                  <div className="p-4 bg-white rounded-2xl border-2 border-dashed border-purple-300 space-y-3.5">
                    <h5 className="text-xs font-black text-purple-900 flex items-center gap-1.5">
                      <Plus className="w-4 h-4 text-purple-700" />
                      <span>Add Color Variant (নতুন কালার যুক্ত করুন)</span>
                    </h5>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {/* Color Name */}
                      <div className="sm:col-span-1">
                        <label className="block text-[11px] font-bold text-zinc-700 mb-1">
                          Color Name (কালারের নাম) *
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Midnight Black, Navy"
                          value={newColorName}
                          onChange={(e) => setNewColorName(e.target.value)}
                          className="w-full bg-zinc-50 text-zinc-900 text-xs p-2.5 rounded-xl border border-zinc-300 focus:outline-none focus:border-purple-600 font-medium"
                        />
                      </div>

                      {/* Color Picker & Hex Code */}
                      <div>
                        <label className="block text-[11px] font-bold text-zinc-700 mb-1">
                          Color Swatch (কালার কোড)
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={newColorCode}
                            onChange={(e) => setNewColorCode(e.target.value)}
                            className="w-9 h-9 p-0.5 rounded-xl border border-zinc-300 cursor-pointer shrink-0 bg-white"
                          />
                          <input
                            type="text"
                            value={newColorCode}
                            onChange={(e) => setNewColorCode(e.target.value)}
                            placeholder="#000000"
                            className="w-full bg-zinc-50 text-zinc-900 text-xs p-2.5 rounded-xl border border-zinc-300 font-mono"
                          />
                        </div>
                      </div>

                      {/* Color Stock */}
                      <div>
                        <label className="block text-[11px] font-bold text-zinc-700 mb-1">
                          Stock for this Color (স্টক সংখ্যা)
                        </label>
                        <input
                          type="number"
                          min="0"
                          value={newColorStock}
                          onChange={(e) => setNewColorStock(Number(e.target.value))}
                          className="w-full bg-zinc-50 text-zinc-900 text-xs p-2.5 rounded-xl border border-zinc-300 font-medium"
                        />
                      </div>
                    </div>

                    {/* Color Image (Optional) */}
                    <div>
                      <label className="block text-[11px] font-bold text-zinc-700 mb-1">
                        Color Specific Image (ঐচ্ছিক - এই কালারের ছবি)
                      </label>
                      <div className="flex flex-col sm:flex-row gap-2 items-stretch sm:items-center">
                        <div className="relative flex-1">
                          <input
                            type="text"
                            placeholder="Image URL or upload below..."
                            value={newColorImageUrl}
                            onChange={(e) => setNewColorImageUrl(e.target.value)}
                            className="w-full bg-zinc-50 text-zinc-900 text-xs pl-8 pr-3 py-2.5 rounded-xl border border-zinc-300"
                          />
                          <ImageIcon className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-3" />
                        </div>

                        <label className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 rounded-xl text-xs font-bold border border-zinc-300 cursor-pointer shrink-0 transition-colors">
                          <Upload className="w-3.5 h-3.5" />
                          <span>{isUploadingColorImage ? 'Uploading...' : 'Device Upload'}</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            disabled={isUploadingColorImage}
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) handleUploadColorImage(file);
                            }}
                          />
                        </label>

                        {newColorImageUrl && (
                          <div className="w-10 h-10 rounded-xl border border-zinc-300 overflow-hidden bg-white shrink-0 self-center">
                            <img src={newColorImageUrl} alt="Color preview" className="w-full h-full object-cover" />
                          </div>
                        )}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleAddColorVariant}
                      className="w-full py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Color to Product (কালার যুক্ত করুন)</span>
                    </button>
                  </div>

                  {/* Current Color Variants List */}
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <h5 className="text-xs font-black text-zinc-900">
                        Added Colors ({editingProduct?.colors?.length || 0}):
                      </h5>
                      {editingProduct?.colors && editingProduct.colors.length > 0 && (
                        <span className="text-[11px] font-semibold text-zinc-500">
                          Total Variant Stock: {editingProduct.colors.reduce((sum, c) => sum + (c.stock || 0), 0)} units
                        </span>
                      )}
                    </div>

                    {editingProduct?.colors && editingProduct.colors.length > 0 ? (
                      <div className="space-y-2">
                        {editingProduct.colors.map((color, index) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-3 rounded-2xl bg-zinc-50 border border-zinc-200 hover:bg-zinc-100/80 transition-colors"
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <span
                                className="w-7 h-7 rounded-full border-2 border-white shadow-md inline-block shrink-0"
                                style={{ backgroundColor: color.code || '#71717a' }}
                              />
                              {color.image_url && (
                                <div className="w-8 h-8 rounded-lg overflow-hidden border border-zinc-300 bg-white shrink-0">
                                  <img src={color.image_url} alt={color.name} className="w-full h-full object-cover" />
                                </div>
                              )}
                              <div className="min-w-0">
                                <div className="flex items-center gap-2">
                                  <span className="font-extrabold text-xs text-zinc-900 truncate">{color.name}</span>
                                  {color.code && (
                                    <span className="font-mono text-[10px] text-zinc-500 uppercase">{color.code}</span>
                                  )}
                                </div>
                                <span className="text-[11px] font-semibold text-emerald-700">
                                  Stock: {color.stock ?? 0} units
                                </span>
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={() => handleRemoveColorVariant(index)}
                              className="p-1.5 text-zinc-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer"
                              title="Remove color variant"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="py-8 text-center bg-zinc-50 rounded-2xl border border-dashed border-zinc-300 p-4">
                        <Palette className="w-8 h-8 text-zinc-400 mx-auto mb-2" />
                        <p className="text-xs font-bold text-zinc-700">No color variants added yet.</p>
                        <p className="text-[11px] text-zinc-500 mt-0.5">
                          Use the form above or click quick color presets to add options for your customers.
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 3: SEO TAB */}
              {productModalTab === 'seo' && (
                <div className="space-y-4 animate-fade-in">
                  {/* Google SEO Introduction Card */}
                  <div className="bg-blue-50/80 border border-blue-200 p-4 rounded-2xl flex items-start gap-3">
                    <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs mt-0.5">
                      <Globe className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-extrabold text-blue-950">Google SEO & Search Rankings (গুগল এসইও কনফিগারেশন)</h4>
                      <p className="text-[11px] text-blue-700 leading-relaxed mt-0.5">
                        গুগল ও অন্যান্য সার্চ ইঞ্জিনে আপনার প্রোডাক্ট সবার উপরে র্যাংক করানোর জন্য কি-ওয়ার্ড, মেটা টাইটেল এবং মেটা ডেসক্রিপশন সেট করুন।
                      </p>
                    </div>
                  </div>

                  {/* 1. Google SEO Keywords (প্রোডাক্ট কি-ওয়ার্ড ও সার্চ ট্যাগ) */}
                  <div className="bg-zinc-50/90 p-4 rounded-2xl border border-zinc-200/90 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <label className="text-xs font-bold text-zinc-800 flex items-center gap-1.5">
                          <Tag className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Google SEO Product Keywords (প্রোডাক্ট কি-ওয়ার্ড) *</span>
                        </label>
                        <p className="text-[11px] text-zinc-500">
                          কমা (,) দিয়ে একাধিক সার্চ কি-ওয়ার্ড লিখুন (যেমন: smart watch bd, amoled calling watch, best watch price)
                        </p>
                      </div>
                      
                      {/* Auto-generate Keywords Button */}
                      <button
                        type="button"
                        onClick={() => {
                          if (!editingProduct) return;
                          const name = (editingProduct.name || '').trim();
                          const cat = (editingProduct.category || '').trim();
                          const subCat = (editingProduct.sub_category || '').trim();
                          const childCat = (editingProduct.child_category || '').trim();
                          
                          const baseList: string[] = [];
                          if (name) {
                            baseList.push(name);
                            baseList.push(`${name} price in bd`);
                            baseList.push(`buy ${name} online`);
                            baseList.push(`original ${name}`);
                          }
                          if (subCat) {
                            baseList.push(subCat);
                            baseList.push(`best ${subCat} in bangladesh`);
                          }
                          if (childCat) {
                            baseList.push(childCat);
                          }
                          if (cat) {
                            baseList.push(`${cat} shop in bd`);
                          }
                          baseList.push('cash on delivery bangladesh');
                          baseList.push('official warranty bd');

                          // Merge with existing keywords without duplicates
                          const existing = (editingProduct.meta_keywords || '')
                            .split(',')
                            .map(k => k.trim())
                            .filter(Boolean);
                          const combined = Array.from(new Set([...existing, ...baseList])).join(', ');
                          setEditingProduct({ ...editingProduct, meta_keywords: combined });
                        }}
                        className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-2xs"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Auto-Suggest Keywords</span>
                      </button>
                    </div>

                    <textarea
                      rows={3}
                      placeholder="e.g. smart watch bd, amoled smartwatch, calling watch, bluetooth watch price in bangladesh, ultra watch series 9"
                      value={editingProduct?.meta_keywords || ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, meta_keywords: e.target.value })}
                      className="w-full bg-white text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900 leading-relaxed"
                    />

                    {/* Active Keyword Chips Preview */}
                    {editingProduct?.meta_keywords && (
                      <div className="space-y-1.5 pt-1">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-bold text-zinc-700 flex items-center gap-1">
                            <Hash className="w-3 h-3 text-zinc-400" />
                            Active Google Keywords ({editingProduct.meta_keywords.split(',').map(k => k.trim()).filter(Boolean).length}):
                          </span>
                          <button
                            type="button"
                            onClick={() => setEditingProduct({ ...editingProduct, meta_keywords: '' })}
                            className="text-rose-600 hover:underline font-semibold cursor-pointer"
                          >
                            Clear All
                          </button>
                        </div>
                        <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto p-1 bg-white rounded-xl border border-zinc-200/80">
                          {editingProduct.meta_keywords
                            .split(',')
                            .map((k) => k.trim())
                            .filter(Boolean)
                            .map((kw, idx) => (
                              <span
                                key={idx}
                                className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200/80 rounded-lg text-xs font-semibold"
                              >
                                <span>{kw}</span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    const filtered = editingProduct.meta_keywords
                                      ?.split(',')
                                      .map(k => k.trim())
                                      .filter((k, i) => i !== idx && k.length > 0)
                                      .join(', ');
                                    setEditingProduct({ ...editingProduct, meta_keywords: filtered || '' });
                                  }}
                                  className="w-3.5 h-3.5 rounded-full hover:bg-emerald-200 text-emerald-900 flex items-center justify-center cursor-pointer ml-0.5"
                                  title="Remove keyword"
                                >
                                  ×
                                </button>
                              </span>
                            ))}
                        </div>
                      </div>
                    )}

                    {/* Quick Add Popular SEO Terms */}
                    <div className="pt-2 border-t border-zinc-200/80">
                      <p className="text-[11px] font-bold text-zinc-500 mb-1.5">Quick Add Search Modifiers (ক্লিক করলেই যুক্ত হবে):</p>
                      <div className="flex flex-wrap gap-1.5">
                        {[
                          'Price in BD',
                          'Best Price in Bangladesh',
                          'Cash on Delivery',
                          'Original Authentic',
                          'Official Warranty',
                          'Online Shopping BD',
                          'Fast Home Delivery'
                        ].map((term) => (
                          <button
                            key={term}
                            type="button"
                            onClick={() => {
                              if (!editingProduct) return;
                              const existing = (editingProduct.meta_keywords || '')
                                .split(',')
                                .map(k => k.trim())
                                .filter(Boolean);
                              const fullTerm = editingProduct.name ? `${editingProduct.name} ${term}` : term;
                              if (!existing.includes(fullTerm)) {
                                existing.push(fullTerm);
                                setEditingProduct({ ...editingProduct, meta_keywords: existing.join(', ') });
                              }
                            }}
                            className="px-2 py-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 rounded-lg text-[11px] font-medium border border-zinc-200 transition-colors cursor-pointer"
                          >
                            + {term}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* 2. SEO Meta Title */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-bold text-zinc-700">
                        SEO Meta Title (Google Search Title)
                      </label>
                      <button
                        type="button"
                        onClick={() => {
                          if (!editingProduct?.name) return;
                          setEditingProduct({
                            ...editingProduct,
                            meta_title: `${editingProduct.name} Price in Bangladesh | Maxora`
                          });
                        }}
                        className="text-[11px] font-semibold text-blue-600 hover:underline cursor-pointer"
                      >
                        Auto-fill from Name
                      </button>
                    </div>
                    <input
                      type="text"
                      placeholder="e.g. Maxora Ultra Smartwatch Series 9 Price in BD | Official Store"
                      value={editingProduct?.meta_title || ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, meta_title: e.target.value })}
                      className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900"
                    />
                    <div className="flex justify-between items-center text-[10px] text-zinc-400 mt-1">
                      <span>গুগল সার্চ ফলাফলের প্রধান শিরোনাম হিসেবে দেখা যাবে।</span>
                      <span>{(editingProduct?.meta_title || '').length} / 60 characters</span>
                    </div>
                  </div>

                  {/* 3. SEO Meta Description */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-bold text-zinc-700">
                        SEO Meta Description (Google Snippet)
                      </label>
                      <button
                        type="button"
                        onClick={() => {
                          if (!editingProduct) return;
                          const name = editingProduct.name || 'Product';
                          const desc = editingProduct.description || '';
                          const snippet = `Buy genuine ${name} at best price in Bangladesh. ${desc.slice(0, 80)}... Cash on delivery available across BD with official warranty. Order online at Maxora.`;
                          setEditingProduct({
                            ...editingProduct,
                            meta_description: snippet
                          });
                        }}
                        className="text-[11px] font-semibold text-blue-600 hover:underline cursor-pointer"
                      >
                        Auto-fill Snippet
                      </button>
                    </div>
                    <textarea
                      rows={2}
                      placeholder="Buy genuine smartwatch in Bangladesh with best price. 100% original product with fast home delivery and cash on delivery at Maxora..."
                      value={editingProduct?.meta_description || ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, meta_description: e.target.value })}
                      className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 resize-none focus:outline-none focus:border-zinc-900"
                    />
                    <div className="flex justify-between items-center text-[10px] text-zinc-400 mt-1">
                      <span>গুগলে সার্চ করার পর শিরোনামের নিচে এই বর্ণনাটি দেখা যাবে।</span>
                      <span>{(editingProduct?.meta_description || '').length} / 160 characters</span>
                    </div>
                  </div>

                  {/* 4. URL Slug */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-bold text-zinc-700">
                        URL Slug (ওয়েব পেজ লিংক)
                      </label>
                      <button
                        type="button"
                        onClick={() => {
                          if (!editingProduct?.name) return;
                          const slug = generateSlug(editingProduct.name);
                          setEditingProduct({ ...editingProduct, slug });
                        }}
                        className="text-[11px] font-semibold text-blue-600 hover:underline cursor-pointer"
                      >
                        Generate Slug
                      </button>
                    </div>
                    <input
                      type="text"
                      placeholder="ultra-smart-watch-series-9"
                      value={editingProduct?.slug || ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, slug: e.target.value })}
                      className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 font-mono"
                    />
                  </div>

                  {/* 5. Live Google Search Snippet Preview */}
                  <div className="p-4 bg-white rounded-2xl border border-zinc-200 shadow-xs space-y-2">
                    <span className="text-xs font-extrabold text-zinc-700 flex items-center gap-1.5">
                      <Globe className="w-3.5 h-3.5 text-blue-600" />
                      <span>Live Google Search Preview (গুগল সার্চে যেমন দেখাবে):</span>
                    </span>
                    <div className="p-3 bg-zinc-50/70 rounded-xl border border-zinc-200/90 font-sans">
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-4 h-4 rounded-full bg-zinc-900 text-white text-[9px] font-bold flex items-center justify-center">
                          M
                        </div>
                        <div className="text-[11px] text-zinc-600 truncate">
                          <span>maxora.com</span>
                          <span className="text-zinc-400 mx-1">›</span>
                          <span className="text-zinc-500">product</span>
                          <span className="text-zinc-400 mx-1">›</span>
                          <span className="text-zinc-700 font-mono">{editingProduct?.slug || 'product-slug'}</span>
                        </div>
                      </div>
                      <h4 className="text-sm font-semibold text-blue-700 hover:underline truncate cursor-pointer">
                        {editingProduct?.meta_title || editingProduct?.name || 'Maxora Premium Product - Buy Online in BD'}
                      </h4>
                      <p className="text-xs text-zinc-600 line-clamp-2 mt-1 leading-relaxed">
                        {editingProduct?.meta_description || editingProduct?.description || 'Discover genuine products in Bangladesh at best prices with nationwide cash on delivery.'}
                      </p>
                      {editingProduct?.meta_keywords && (
                        <div className="mt-2 pt-2 border-t border-zinc-200/70 flex items-center gap-1.5 flex-wrap">
                          <span className="text-[10px] text-zinc-400 font-semibold">Indexed Keywords:</span>
                          {editingProduct.meta_keywords
                            .split(',')
                            .slice(0, 4)
                            .map((k, i) => (
                              <span key={i} className="text-[10px] bg-blue-50 text-blue-800 px-1.5 py-0.5 rounded font-medium border border-blue-100">
                                {k.trim()}
                              </span>
                            ))}
                          {editingProduct.meta_keywords.split(',').length > 4 && (
                            <span className="text-[10px] text-zinc-400">
                              +{editingProduct.meta_keywords.split(',').length - 4} more
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              <div className="pt-3">
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-zinc-950 hover:bg-zinc-800 text-white font-extrabold text-sm transition-all shadow-md cursor-pointer"
                >
                  Save Product
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ====================================================
          MANAGE CUSTOM PRODUCT TYPES MODAL
      ==================================================== */}
      {isManageTypesModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-zinc-950/70 backdrop-blur-sm animate-fade-in">
          <div className="relative bg-white w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl border border-zinc-200 flex flex-col">
            <div className="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-zinc-900 text-white flex items-center justify-center font-bold">
                  <Tag className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-zinc-900">
                    Product Types Management
                  </h3>
                  <p className="text-xs text-zinc-500">প্রোডাক্টের টাইপসমূহ তৈরি ও নিয়ন্ত্রণ করুন</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsManageTypesModalOpen(false)}
                className="w-8 h-8 rounded-full border border-zinc-200 flex items-center justify-center text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-5">
              {/* Add New Type Input */}
              <div>
                <label className="block text-xs font-bold text-zinc-800 mb-1.5">
                  Create New Product Type (নতুন প্রোডাক্ট টাইপ যোগ করুন)
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="e.g. Export Quality, Wholesale, Gift Hamper..."
                    value={newProductTypeInput}
                    onChange={(e) => setNewProductTypeInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewProductType();
                      }
                    }}
                    className="flex-1 bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900 font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => handleAddNewProductType()}
                    className="px-4 py-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Type</span>
                  </button>
                </div>
              </div>

              {/* Existing Types List */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-zinc-700">
                    Active Product Types ({availableProductTypes.length}):
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm('Reset product types to standard defaults?')) {
                        const defaults = [
                          'Standard Product',
                          'Variant Product',
                          'Combo Offer',
                          'Physical Product',
                          'Digital Product',
                          'Pre-Order',
                          'Hot Deal'
                        ];
                        setAvailableProductTypes(defaults);
                        localStorage.setItem('maxora_custom_product_types', JSON.stringify(defaults));
                        showToast('Reset to default product types', 'info');
                      }
                    }}
                    className="text-[11px] font-semibold text-zinc-500 hover:text-zinc-800 underline cursor-pointer"
                  >
                    Reset Defaults
                  </button>
                </div>

                <div className="max-h-64 overflow-y-auto space-y-1.5 pr-1">
                  {availableProductTypes.map((type) => {
                    const isDefault = [
                      'Standard Product',
                      'Variant Product',
                      'Combo Offer',
                      'Physical Product',
                      'Digital Product',
                      'Pre-Order',
                      'Hot Deal'
                    ].includes(type);

                    return (
                      <div
                        key={type}
                        className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-50 border border-zinc-200 hover:bg-zinc-100/80 transition-colors"
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                          <span className="text-xs font-bold text-zinc-900 truncate">{type}</span>
                          {isDefault && (
                            <span className="text-[10px] bg-zinc-200 text-zinc-600 px-1.5 py-0.5 rounded font-medium">
                              Default
                            </span>
                          )}
                        </div>

                        {!isDefault && (
                          <button
                            type="button"
                            onClick={() => handleDeleteProductType(type)}
                            className="p-1 text-zinc-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            title="Delete custom product type"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="p-4 bg-zinc-50 border-t border-zinc-200 flex justify-end">
              <button
                type="button"
                onClick={() => setIsManageTypesModalOpen(false)}
                className="px-5 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ====================================================
          ORDER MODAL (EDIT & DETAILS)
      ==================================================== */}
      {isOrderModalOpen && editingOrder && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-zinc-950/70 backdrop-blur-sm">
          <div className="relative bg-white w-full max-w-xl rounded-3xl overflow-hidden shadow-2xl border border-zinc-200 max-h-[92vh] flex flex-col">
            <div className="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50">
              <div>
                <h3 className="font-extrabold text-base text-zinc-900">
                  Edit Order #{editingOrder.order_number}
                </h3>
                <span className="text-xs text-zinc-500 font-mono">ID: {editingOrder.id}</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedOrderForInvoice(editingOrder)}
                  className="px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Invoice</span>
                </button>
                <button
                  onClick={() => setIsOrderModalOpen(false)}
                  className="w-8 h-8 rounded-full border border-zinc-200 flex items-center justify-center text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100"
                >
                  ✕
                </button>
              </div>
            </div>

            <form onSubmit={handleSaveOrder} className="p-6 overflow-y-auto space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">
                    Customer Name
                  </label>
                  <input
                    type="text"
                    value={editingOrder.customer_name}
                    onChange={(e) => setEditingOrder({ ...editingOrder, customer_name: e.target.value })}
                    className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    value={editingOrder.phone}
                    onChange={(e) => setEditingOrder({ ...editingOrder, phone: e.target.value })}
                    className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">
                    District
                  </label>
                  <select
                    value={editingOrder.district}
                    onChange={(e) => setEditingOrder({ ...editingOrder, district: e.target.value })}
                    className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300"
                  >
                    {BD_DISTRICTS.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">
                    Area / Thana
                  </label>
                  <select
                    value={editingOrder.area}
                    onChange={(e) => setEditingOrder({ ...editingOrder, area: e.target.value })}
                    className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300"
                  >
                    {getThanasForDistrict(editingOrder.district || 'Dhaka').map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                    {editingOrder.area && !getThanasForDistrict(editingOrder.district || 'Dhaka').includes(editingOrder.area) && (
                      <option value={editingOrder.area}>{editingOrder.area}</option>
                    )}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 mb-1">
                  Full Address
                </label>
                <textarea
                  rows={2}
                  value={editingOrder.address}
                  onChange={(e) => setEditingOrder({ ...editingOrder, address: e.target.value })}
                  className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 resize-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">
                    Subtotal (৳)
                  </label>
                  <input
                    type="number"
                    value={editingOrder.subtotal}
                    onChange={(e) => {
                      const sub = Number(e.target.value);
                      setEditingOrder({
                        ...editingOrder,
                        subtotal: sub,
                        total: sub + Number(editingOrder.delivery_charge || 0),
                      });
                    }}
                    className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">
                    Delivery (৳)
                  </label>
                  <input
                    type="number"
                    value={editingOrder.delivery_charge}
                    onChange={(e) => {
                      const del = Number(e.target.value);
                      setEditingOrder({
                        ...editingOrder,
                        delivery_charge: del,
                        total: Number(editingOrder.subtotal || 0) + del,
                      });
                    }}
                    className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">
                    Grand Total (৳)
                  </label>
                  <input
                    type="number"
                    value={editingOrder.total}
                    onChange={(e) => setEditingOrder({ ...editingOrder, total: Number(e.target.value) })}
                    className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 mb-1">
                  Order Status
                </label>
                <select
                  value={editingOrder.status}
                  onChange={(e) => setEditingOrder({ ...editingOrder, status: e.target.value as OrderStatus })}
                  className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 font-bold"
                >
                  <option value="Pending">Pending (Awaiting phone confirmation)</option>
                  <option value="Confirmed">Confirmed</option>
                  <option value="Processing">Processing (Packaging)</option>
                  <option value="Shipped">Shipped (With courier)</option>
                  <option value="Delivered">Delivered</option>
                  <option value="Cancelled">Cancelled</option>
                  <option value="Returned">Returned</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 mb-1">
                  Order Note / Customer Remarks
                </label>
                <input
                  type="text"
                  value={editingOrder.note || ''}
                  onChange={(e) => setEditingOrder({ ...editingOrder, note: e.target.value })}
                  className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300"
                />
              </div>

              <div className="pt-2 flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => handleDeleteOrder(editingOrder.id, editingOrder.order_number)}
                  className="px-4 py-3.5 rounded-2xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-sm transition-all border border-rose-200 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Delete Order</span>
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3.5 rounded-2xl bg-zinc-950 hover:bg-zinc-800 text-white font-extrabold text-sm transition-all shadow-md cursor-pointer"
                >
                  Update Order Details
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ====================================================
          CATEGORY EDIT MODAL (SETTINGS & CATEGORIES)
      ==================================================== */}
      {isCategoryEditModalOpen && categoryToEdit && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-zinc-950/70 backdrop-blur-sm animate-fade-in">
          <div className="relative bg-white w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl border border-zinc-200 flex flex-col">
            <div className="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center border border-emerald-500/20">
                  <FolderTree className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-zinc-900">
                    {categoryToEdit.id && dbCategories.some((c) => c.id === categoryToEdit.id)
                      ? 'Edit Category'
                      : 'Add New Category'}
                  </h3>
                  <p className="text-xs text-zinc-500">
                    Update name, URL slug & visibility. Saved directly to Firestore.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsCategoryEditModalOpen(false);
                  setCategoryToEdit(null);
                }}
                className="w-8 h-8 rounded-full bg-zinc-200/70 hover:bg-zinc-200 text-zinc-600 hover:text-zinc-900 flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveCategoryEditModal} className="p-6 space-y-5">
              {/* Category Name */}
              <div>
                <label className="block text-xs font-bold text-zinc-700 mb-1.5">
                  Category Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Smart Watch or স্মার্টওয়াচ"
                  value={categoryToEdit.name || ''}
                  onChange={(e) => {
                    const newName = e.target.value;
                    setCategoryToEdit({
                      ...categoryToEdit,
                      name: newName,
                      slug: categoryToEdit.slug || generateSlug(newName),
                    });
                  }}
                  className="w-full bg-zinc-50 text-zinc-900 text-sm p-3 rounded-xl border border-zinc-300 focus:outline-none focus:border-zinc-900 font-semibold"
                />
              </div>

              {/* Category Slug */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-bold text-zinc-700">
                    Category URL Slug <span className="text-rose-500">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      if (categoryToEdit.name) {
                        setCategoryToEdit({
                          ...categoryToEdit,
                          slug: generateSlug(categoryToEdit.name),
                        });
                      }
                    }}
                    className="text-[11px] text-emerald-600 hover:underline font-bold cursor-pointer"
                  >
                    Auto-Generate
                  </button>
                </div>
                <div className="flex items-center rounded-xl border border-zinc-300 bg-zinc-50 overflow-hidden focus-within:border-zinc-900">
                  <span className="px-3 text-xs text-zinc-400 font-mono select-none bg-zinc-100 py-3 border-r border-zinc-200">
                    /category/
                  </span>
                  <input
                    type="text"
                    required
                    placeholder="smart-watch"
                    value={categoryToEdit.slug || ''}
                    onChange={(e) =>
                      setCategoryToEdit({
                        ...categoryToEdit,
                        slug: e.target.value.toLowerCase().replace(/\s+/g, '-'),
                      })
                    }
                    className="w-full bg-transparent text-zinc-900 text-xs sm:text-sm p-3 focus:outline-none font-mono"
                  />
                </div>
                <span className="text-[11px] text-zinc-400 block mt-1">
                  Used in browser address bar and SEO canonical URLs
                </span>
              </div>

              {/* Category Status Selector */}
              <div>
                <label className="block text-xs font-bold text-zinc-700 mb-2">
                  Storefront Visibility Status <span className="text-rose-500">*</span>
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setCategoryToEdit({ ...categoryToEdit, active: 1 })}
                    className={`p-3.5 rounded-2xl border text-left flex items-start gap-3 transition-all cursor-pointer ${
                      categoryToEdit.active !== 0
                        ? 'bg-emerald-50/80 border-emerald-500 ring-2 ring-emerald-500/20 text-emerald-950 shadow-xs'
                        : 'bg-zinc-50 border-zinc-200 text-zinc-600 hover:bg-zinc-100'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 ${
                        categoryToEdit.active !== 0
                          ? 'border-emerald-600 bg-emerald-600 text-white'
                          : 'border-zinc-300 bg-white'
                      }`}
                    >
                      {categoryToEdit.active !== 0 && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                    <div>
                      <span className="block text-xs font-extrabold text-zinc-900">
                        Active (প্রদর্শিত)
                      </span>
                      <span className="block text-[11px] text-zinc-500 mt-0.5">
                        Visible on website navbar, filter tabs & search
                      </span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCategoryToEdit({ ...categoryToEdit, active: 0 })}
                    className={`p-3.5 rounded-2xl border text-left flex items-start gap-3 transition-all cursor-pointer ${
                      categoryToEdit.active === 0
                        ? 'bg-amber-50/80 border-amber-500 ring-2 ring-amber-500/20 text-amber-950 shadow-xs'
                        : 'bg-zinc-50 border-zinc-200 text-zinc-600 hover:bg-zinc-100'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 ${
                        categoryToEdit.active === 0
                          ? 'border-amber-600 bg-amber-600 text-white'
                          : 'border-zinc-300 bg-white'
                      }`}
                    >
                      {categoryToEdit.active === 0 && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                    <div>
                      <span className="block text-xs font-extrabold text-zinc-900">
                        Hidden (লুকানো)
                      </span>
                      <span className="block text-[11px] text-zinc-500 mt-0.5">
                        Hidden from storefront, products stay preserved
                      </span>
                    </div>
                  </button>
                </div>
              </div>

              {/* Display Order */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">
                    Display Order
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={categoryToEdit.display_order ?? 1}
                    onChange={(e) =>
                      setCategoryToEdit({
                        ...categoryToEdit,
                        display_order: Number(e.target.value) || 1,
                      })
                    }
                    className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300 font-bold"
                  />
                  <span className="text-[10px] text-zinc-400 block mt-1">
                    1 = first item on menu
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">
                    Icon Identifier (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Watch, Headphones"
                    value={categoryToEdit.icon || ''}
                    onChange={(e) =>
                      setCategoryToEdit({
                        ...categoryToEdit,
                        icon: e.target.value,
                      })
                    }
                    className="w-full bg-zinc-50 text-zinc-900 text-xs sm:text-sm p-3 rounded-xl border border-zinc-300"
                  />
                  <span className="text-[10px] text-zinc-400 block mt-1">
                    Lucide icon name or tag
                  </span>
                </div>
              </div>

              {/* Modal Actions */}
              <div className="pt-3 border-t border-zinc-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  disabled={isSavingCategory}
                  onClick={() => {
                    setIsCategoryEditModalOpen(false);
                    setCategoryToEdit(null);
                  }}
                  className="px-4 py-2.5 rounded-xl border border-zinc-200 hover:bg-zinc-100 text-zinc-700 font-bold text-xs transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingCategory || !categoryToEdit.name?.trim()}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-extrabold text-xs transition-all shadow-md cursor-pointer"
                >
                  {isSavingCategory ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Saving to Firestore...</span>
                    </>
                  ) : (
                    <>
                      <Save className="w-3.5 h-3.5" />
                      <span>Save Changes to Firestore</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Customer Orders History Modal */}
      <CustomerOrdersModal
        customer={selectedCustomerForHistory}
        orders={orders}
        onClose={() => setSelectedCustomerForHistory(null)}
        onSelectOrder={(ord) => {
          setEditingOrder(ord);
          setIsOrderModalOpen(true);
        }}
      />

      {/* Printable Invoice Modal */}
      <InvoiceModal
        order={selectedOrderForInvoice}
        settings={settingsForm}
        products={products}
        onClose={() => setSelectedOrderForInvoice(null)}
        onOpenProduct={(p) => {
          setSelectedOrderForInvoice(null);
          const slug = getProductSlug(p);
          if (slug && typeof window !== 'undefined') {
            window.open(`/product/${slug}`, '_blank', 'noopener,noreferrer');
          }
        }}
      />
    </div>
  );
};
